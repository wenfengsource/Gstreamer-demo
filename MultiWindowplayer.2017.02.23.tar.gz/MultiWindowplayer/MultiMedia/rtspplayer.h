#ifndef RTSPPLAYER_H
#define RTSPPLAYER_H

#include <QFrame>
#include "defines.h"



/* Structure to contain all our information, so we can pass it to callbacks */
typedef struct  {
  GstElement *pipeline;
  GstElement *source;
  GstElement *rtph264depay;
  GstElement *h264parse;
  GstElement *decode;
  GstElement *sink;
  GstElement *videoconvert;

} CustomData;


namespace Ui {
class rtspplayer;
}

class rtspplayer : public QFrame
{
    Q_OBJECT

public:
    explicit rtspplayer(QWidget *parent = 0);
    ~rtspplayer();

    void createplayer(bool decodesel);
    void showframe(QRect &rect);
    void hide();

private slots:
    void playerslot();
    void stopslot();
    void NoRenderStateChangeslot(int);

public:
    CustomData data;
    GstBus *bus;
    GstMessage *msg;
    GstStateChangeReturn ret;

    QString rtsp_url;
    QString user_id;
    QString user_pw;


private:
    bool softdec_flag;

    int pipelinestate;


    Ui::rtspplayer *ui;
};

#endif // RTSPPLAYER_H
