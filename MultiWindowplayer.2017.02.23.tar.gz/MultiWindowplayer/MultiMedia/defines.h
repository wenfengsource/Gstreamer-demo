#ifndef DEFINES_H
#define DEFINES_H


#include <glib.h>
#include <gst/gst.h>
#include <gst/video/videooverlay.h>
#include <QString>
#include <QDebug>
#include <stdio.h>
#include <unistd.h>

#define dprintf(x...) printf("ui: " x);
//#define dprintf(x...)


#define MAX_CHANNEL     16
#define PANNEL_WIDTH     (1920 -50)
#define PANNEL_HEIGHT    (1080 -50)


/* Structure to contain all our information, so we can pass it to callbacks */
typedef struct _CustomData {
  GstElement *pipeline;
  GstElement *source;
  GstElement *sdpdemux;
  GstElement *decodebin;

  GstElement *videoconvert;

  GstElement *sink;

  GstBus *bus;
  int loop_player;

} GstCustomData;



#endif // DEFINES_H


