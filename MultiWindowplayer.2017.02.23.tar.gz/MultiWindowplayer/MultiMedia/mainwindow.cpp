#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <X11/Xlib.h>
#include <X11/Xutil.h>

#define COL  3
#define LINE   3

#define APP_WIDTH    ((m_srceen_width -50)  )
#define APP_HEIGHT   ((m_sreen_height -50)  )


int m_srceen_width;
int m_sreen_height;

/*Get currently X window resolution */
static int get_screen_resolution (int *pwidth, int *pheight/*Bool current*/)
{
    Display *dpy;
    int	screen = -1;
    if (!(dpy = XOpenDisplay(NULL)))
    {
        printf(" XOpenDisplay() error !\n");
        return -1;
    }
    screen = DefaultScreen (dpy);
    *pwidth = DisplayWidth (dpy, screen);
    *pheight = DisplayHeight(dpy, screen);
    return 0;

}


MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    m_rtspplayer = false;
    m_localfileplayer = false;

    connect(ui->localfileplayer, SIGNAL(clicked()), this, SLOT(playerlocalfileSlot() ));
    connect(ui->rtspplayer, SIGNAL(clicked()), this, SLOT(playerrtspSlot()));
    connect(ui->AxisMulticastPlayer, SIGNAL(clicked()), this, SLOT(playeraxismulticastpalyerSlot()));

    get_screen_resolution(&m_srceen_width, &m_sreen_height);

    CreateRtspPlayer();

}

void MainWindow::showframe()
{
    QRect a;

    a.setRect(0,0, m_srceen_width ,m_sreen_height );

    this->setGeometry(a);
    this->show();
}

void MainWindow::CreateMediaPlayer()
{
    int i, j;

    m_localfileplayer = true;

   for(i= 0; i < LINE; i++)
    {
       for(j = 0; j< COL; j++)
       {
            QRect a;

            a.setRect(APP_WIDTH/LINE*i,APP_HEIGHT/COL*j + 30, APP_WIDTH/COL,APP_HEIGHT/COL);
            // a.setX(100);
            //  a.setY(100);
            pmediaplayer[i][j] = new mediaplayer;
            pmediaplayer[i][j]->setParent(this);
            pmediaplayer[i][j]->showframe(a);
            pmediaplayer[i][j]->setplayer_id(i*COL + j);

       }

    }


}

void MainWindow::playerlocalfileSlot()
{
    dprintf("CreateMediaPlayer \n");
    if(m_localfileplayer == false)
    {
        m_localfileplayer = true;
        CreateMediaPlayer();
    }

    if(m_rtspplayer == true)
    {
        m_rtspplayer = false;
        for(int i=0; i < COL; i++)
        {
            for(int j=0; j < COL; j++)
            {
                 prtspplayer[i][j]->hide();
                 delete  prtspplayer[i][j];
            }
        }
    }
    if(m_axismulticastplayer == true)
    {
        m_axismulticastplayer = false;

        for(int i=0; i < COL; i++)
        {
            for(int j=0; j < COL; j++)
            {
                 delete  paxismulticastplayer[i][j];
            }
        }
    }
}

void MainWindow::playerrtspSlot()
{
    dprintf("CreateRtspPlayer \n");
    if(m_rtspplayer == false)
    {
        m_rtspplayer = true;
        CreateRtspPlayer();
    }

    if(m_localfileplayer == true)
    {
        m_localfileplayer = false;

        for(int i=0; i < COL; i++)
        {
            for(int j=0; j < COL; j++)
            {
                 delete  pmediaplayer[i][j];
            }
        }
    }
    if(m_axismulticastplayer == true)
    {
        m_axismulticastplayer = false;

        for(int i=0; i < COL; i++)
        {
            for(int j=0; j < COL; j++)
            {
                 delete  paxismulticastplayer[i][j];
            }
        }
    }
}



void MainWindow::CreateRtspPlayer()
{
     int i, j;

      m_rtspplayer = true;

   for(i= 0; i < COL; i++)
   {
      for(j = 0; j< LINE; j++)
      {
           QRect a;

           a.setRect(APP_WIDTH/LINE*i,APP_HEIGHT/COL*j + 30, APP_WIDTH/COL,APP_HEIGHT/COL);
           // a.setX(100);
           //  a.setY(100);
           prtspplayer[i][j] = new rtspplayer;
           prtspplayer[i][j]->setParent(this);
           prtspplayer[i][j]->showframe(a);
      }

   }
}


void MainWindow::playeraxismulticastpalyerSlot()
{
      dprintf("playeraxismulticastpalyerSlot \n");

      if(m_axismulticastplayer == true)
      {
          return;
      }
      if(m_axismulticastplayer == false)
      {
          m_axismulticastplayer = true;
          CreateAxisMultiCastPlayer();
      }

      if(m_localfileplayer == true)
      {
          m_localfileplayer = false;

          for(int i=0; i < COL; i++)
          {
              for(int j=0; j < COL; j++)
              {
                   delete  pmediaplayer[i][j];
              }
          }
      }
      if(m_rtspplayer == true)
      {
          m_rtspplayer = false;
          for(int i=0; i < COL; i++)
          {
              for(int j=0; j < COL; j++)
              {
                   prtspplayer[i][j]->hide();
                   delete  prtspplayer[i][j];
              }
          }
      }
}

void MainWindow::CreateAxisMultiCastPlayer()
{
     int i, j;

      m_axismulticastplayer = true;

   for(i= 0; i < COL; i++)
   {
      for(j = 0; j< LINE; j++)
      {
           QRect a;

           a.setRect(APP_WIDTH/LINE*i,APP_HEIGHT/COL*j + 30, APP_WIDTH/COL,APP_HEIGHT/COL);
           // a.setX(100);
           //  a.setY(100);
           paxismulticastplayer[i][j] = new AxisMulticastPlayer;
           paxismulticastplayer[i][j]->setParent(this);
           paxismulticastplayer[i][j]->showframe(a);
      }

   }
}


MainWindow::~MainWindow()
{
    if(m_localfileplayer == true)
    {
        for(int i=0; i < COL; i++)
        {
            for(int j=0; j < COL; j++)
            {
                 delete  pmediaplayer[i][j];
            }
        }
    }

    if(m_rtspplayer == true)
    {
        for(int i=0; i < COL; i++)
        {
            for(int j=0; j < COL; j++)
            {
                 delete  prtspplayer[i][j];
            }
        }
    }

    if(m_axismulticastplayer == true)
    {
        for(int i=0; i < COL; i++)
        {
            for(int j=0; j < COL; j++)
            {
                 delete  paxismulticastplayer[i][j];
            }
        }
    }



    delete ui;
}
