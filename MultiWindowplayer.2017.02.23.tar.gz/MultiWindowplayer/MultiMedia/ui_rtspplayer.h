/********************************************************************************
** Form generated from reading UI file 'rtspplayer.ui'
**
** Created by: Qt User Interface Compiler version 5.2.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_RTSPPLAYER_H
#define UI_RTSPPLAYER_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QFrame>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_rtspplayer
{
public:
    QPushButton *player;
    QPushButton *stop;
    QLabel *label;
    QLineEdit *rtspurl;
    QLineEdit *user_id;
    QLineEdit *user_pw;
    QFrame *video;
    QLabel *label_2;
    QLabel *label_3;
    QCheckBox *softdec;

    void setupUi(QFrame *rtspplayer)
    {
        if (rtspplayer->objectName().isEmpty())
            rtspplayer->setObjectName(QStringLiteral("rtspplayer"));
        rtspplayer->resize(756, 372);
        rtspplayer->setFrameShape(QFrame::StyledPanel);
        rtspplayer->setFrameShadow(QFrame::Raised);
        player = new QPushButton(rtspplayer);
        player->setObjectName(QStringLiteral("player"));
        player->setGeometry(QRect(480, 320, 51, 27));
        stop = new QPushButton(rtspplayer);
        stop->setObjectName(QStringLiteral("stop"));
        stop->setGeometry(QRect(530, 320, 81, 27));
        label = new QLabel(rtspplayer);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(10, 320, 51, 17));
        rtspurl = new QLineEdit(rtspplayer);
        rtspurl->setObjectName(QStringLiteral("rtspurl"));
        rtspurl->setGeometry(QRect(60, 320, 141, 27));
        user_id = new QLineEdit(rtspplayer);
        user_id->setObjectName(QStringLiteral("user_id"));
        user_id->setGeometry(QRect(230, 320, 41, 27));
        user_pw = new QLineEdit(rtspplayer);
        user_pw->setObjectName(QStringLiteral("user_pw"));
        user_pw->setGeometry(QRect(310, 320, 41, 27));
        video = new QFrame(rtspplayer);
        video->setObjectName(QStringLiteral("video"));
        video->setGeometry(QRect(0, 0, 621, 321));
        video->setStyleSheet(QStringLiteral("background-color: rgb(0, 0, 0);"));
        video->setFrameShape(QFrame::StyledPanel);
        video->setFrameShadow(QFrame::Raised);
        label_2 = new QLabel(rtspplayer);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(210, 320, 16, 17));
        label_3 = new QLabel(rtspplayer);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(280, 320, 31, 17));
        softdec = new QCheckBox(rtspplayer);
        softdec->setObjectName(QStringLiteral("softdec"));
        softdec->setGeometry(QRect(370, 320, 97, 22));

        retranslateUi(rtspplayer);

        QMetaObject::connectSlotsByName(rtspplayer);
    } // setupUi

    void retranslateUi(QFrame *rtspplayer)
    {
        rtspplayer->setWindowTitle(QApplication::translate("rtspplayer", "Frame", 0));
        player->setText(QApplication::translate("rtspplayer", "player", 0));
        stop->setText(QApplication::translate("rtspplayer", "stop", 0));
        label->setText(QApplication::translate("rtspplayer", "rtsp", 0));
        rtspurl->setText(QApplication::translate("rtspplayer", "rtsp://192.168.0.10/axis-media/media.amp?camera=1", 0));
        user_id->setText(QApplication::translate("rtspplayer", "root", 0));
        user_pw->setText(QApplication::translate("rtspplayer", "root", 0));
        label_2->setText(QApplication::translate("rtspplayer", "id", 0));
        label_3->setText(QApplication::translate("rtspplayer", "pw", 0));
        softdec->setText(QApplication::translate("rtspplayer", "SoftDec", 0));
    } // retranslateUi

};

namespace Ui {
    class rtspplayer: public Ui_rtspplayer {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_RTSPPLAYER_H
