#include "mediaplayer.h"
#include "ui_mediaplayer.h"
#include <QFileDialog>
#include <pthread.h>


static void error_cb (GstBus *bus, GstMessage *msg, GstCustomData *data);
static void eos_cb (GstBus *bus, GstMessage *msg, GstCustomData *data);
static void state_changed_cb (GstBus *bus, GstMessage *msg, GstCustomData *data);
static void pad_added_handler(GstElement *src, GstPad *new_pad, GstElement *sink);



void  *startplayerthread(void *id);

//GstCustomData data;
//GstBus *bus;
//GstMessage *msg;
//GstStateChangeReturn ret;
//gboolean terminate;

 //WId winid ;
//pthread_t tid;

QString g_filename[16];
WId g_winid[16];
int g_thread_exit_flag[16];
 GstCustomData g_data[16];

/* decodebin to nvglessink pad add and link */
static void pad_added_handler(GstElement *src, GstPad *new_pad, GstElement *sink)
{

     GstPad *sink_pad = gst_element_get_static_pad (sink, "sink");
     GstPadLinkReturn ret;
     GstCaps *new_pad_caps = NULL;
     GstStructure *new_pad_struct = NULL;
     const gchar *new_pad_type = NULL;

     g_print ("Received new pad '%s' from '%s':\n", GST_PAD_NAME (new_pad), GST_ELEMENT_NAME (src));

     /* If our converter is already linked, we have nothing to do here */
     if (gst_pad_is_linked (sink_pad)) {
       g_print ("  We are already linked. Ignoring.\n");
       goto exit;
     }

     /* Check the new pad's type */
     new_pad_caps = gst_pad_get_current_caps (new_pad);
   //  new_pad_caps = gst_pad_get_caps (new_pad);

     new_pad_struct = gst_caps_get_structure (new_pad_caps, 0);
     new_pad_type = gst_structure_get_name (new_pad_struct);
     if (!g_str_has_prefix (new_pad_type, "video/x-raw")) {
       g_print ("  It has type '%s' which is not video audio. Ignoring.\n", new_pad_type);
       goto exit;
     }

     /* Attempt the link */
     ret = gst_pad_link (new_pad, sink_pad);
     if (GST_PAD_LINK_FAILED (ret)) {
       g_print ("  Type is '%s' but link failed.\n", new_pad_type);
     } else {
       g_print ("  Link succeeded (type '%s').\n", new_pad_type);
     }

   exit:
     /* Unreference the new pad's caps, if we got them */
     if (new_pad_caps != NULL)
       gst_caps_unref (new_pad_caps);

     /* Unreference the sink pad */
     gst_object_unref (sink_pad);
}

/* This function is called when an error message is posted on the bus */
static void error_cb (GstBus *bus, GstMessage *msg, GstCustomData *data)
{
    GError *err;
    gchar *debug_info;

    /* Print error details on the screen */
    gst_message_parse_error (msg, &err, &debug_info);
    g_printerr ("Error received from element %s: %s\n", GST_OBJECT_NAME (msg->src), err->message);
    g_printerr ("Debugging information: %s\n", debug_info ? debug_info : "none");
    g_clear_error (&err);
    g_free (debug_info);

    /* Set the pipeline to READY (which stops playback) */
    gst_element_set_state (data->pipeline, GST_STATE_READY);
}


/* This function is called when an End-Of-Stream message is posted on the bus.
 * We just set the pipeline to READY (which stops playback) */
static void eos_cb (GstBus *bus, GstMessage *msg, GstCustomData *data)
{
    g_print ("End-Of-Stream reached.\n");
    if(data->loop_player == true)
    {
        gst_element_set_state (data->pipeline, GST_STATE_READY);
        usleep(1000);
        gst_element_set_state (data->pipeline,GST_STATE_PLAYING);
    }
    else
    {
        gst_element_set_state (data->pipeline, GST_STATE_READY);
    }
}

/* This function is called when the pipeline changes states. We use it to
 * keep track of the current state. */
static void state_changed_cb (GstBus *bus, GstMessage *msg, GstCustomData *data)
{
    GstState old_state, new_state, pending_state;
    gst_message_parse_state_changed (msg, &old_state, &new_state, &pending_state);
    if (GST_MESSAGE_SRC (msg) == GST_OBJECT (data->pipeline))
    {
         //  data->state = new_state;
        g_print ("State set to %s\n", gst_element_state_get_name (new_state));
        if (old_state == GST_STATE_READY && new_state == GST_STATE_PAUSED)
        {
          /* For extra responsiveness, we refresh the GUI as soon as we reach the PAUSED state */

        }
    }
}



mediaplayer::mediaplayer(QWidget *parent) :
    QFrame(parent),
    ui(new Ui::mediaplayer)
{
    ui->setupUi(this);

   connect(ui->player, SIGNAL(clicked()), this, SLOT(playerslot()));
     connect(ui->stop, SIGNAL(clicked()), this, SLOT(stopplayerslot()));
     connect(ui->open, SIGNAL(clicked()), this, SLOT(getvideo_urislot()));
     connect(ui->loop, SIGNAL(clicked()), this, SLOT(loopplayerslot()));


//    data.pipeline = NULL;
//    bus = NULL;
//     data.loop_player = true;
}



void mediaplayer::showframe(QRect &rect)
{
    QSize b;

   //  rect.adjust(0,0,1920/2,1080/2);
  //  a.setHeight(1080/2);
  //  a.setWidth(1920/2);
    this->setGeometry(rect);

    //dprintf("a.width() = %d\n", rect.width());
   //dprintf("a.Hight() = %d\n", rect.height());

    b.setHeight(rect.height()-30);
    b.setWidth(rect.width());
    ui->video->resize(b);
    ui->open->setGeometry(0, rect.height() - 25,50,25);
    ui->player->setGeometry(70,rect.height() - 25,50,25);
    ui->stop->setGeometry(140, rect.height() - 25,50,25);
    ui->pause->setGeometry(210, rect.height() - 25,50,25);
    ui->loop->setGeometry(280, rect.height() - 25,80,25);
    ui->SoftDec->setGeometry(380, rect.height() - 25,80,25);
    this->show();

}

void mediaplayer::setplayer_id(int id)
{
    player_id = id;
    g_data[player_id].bus = NULL;
    g_data[player_id].pipeline = NULL;

    g_thread_exit_flag[player_id] = true;
}

mediaplayer::~mediaplayer()
{

      void *tret;
    if( g_thread_exit_flag[player_id] != true)
    {
        g_thread_exit_flag[player_id] = true;

        if(g_data[player_id].bus != NULL)
        {
            gst_object_unref (g_data[player_id].bus);
            g_data[player_id].bus = NULL;
        }

        if( g_data[player_id].pipeline != NULL)
        {
           gst_element_set_state ( g_data[player_id].pipeline, GST_STATE_READY);
           gst_element_set_state ( g_data[player_id].pipeline, GST_STATE_NULL);
           gst_object_unref ( g_data[player_id].pipeline);
        }

        pthread_join(tid, &tret);  // Waitting thread tid exit

   }
  //  dprintf("mediaplayer thread exit \n");


    delete ui;
}


/* filesrc -> decodebin -> nveglglessink  */
void createplayer(GstCustomData *data)
{
    //GstCustomData data = *pdata;
    gst_init(NULL,NULL);
    /* Create the elements */
    data->source = gst_element_factory_make ("filesrc", "source");
    data->decodebin = gst_element_factory_make ("decodebin", "decodebin");
    data->sink = gst_element_factory_make ("xvimagesink", "sink");
    data->videoconvert = gst_element_factory_make ("nvvidconv", "videoconvert");
    /* Create the empty pipeline */
    data->pipeline = gst_pipeline_new ("test-pipeline");

//    if (!data.pipeline || !data.source || !data.sink) {
//    g_printerr ("Not all elements could be created.\n");
//    //  return -1;
//    }

   // if(ui->SoftDec->isChecked() == false)
    {
      //gst_plugin_feature_set_rank(GST_PLUGIN_FEATURE(gst_element_factory_find("omxh264dec")),GST_RANK_PRIMARY+10);
      gst_bin_add_many (GST_BIN (data->pipeline), data->source,data->decodebin,data->videoconvert,data->sink,  NULL);
    }
  //  else
 //   {
 //     gst_plugin_feature_set_rank(GST_PLUGIN_FEATURE(gst_element_factory_find("omxh264dec")),GST_RANK_NONE);
  //    gst_bin_add_many (GST_BIN (data.pipeline), data.source,data.decodebin,data.sink,  NULL);
//    }



   // gst_bin_add_many (GST_BIN (data->pipeline), data->source,data->decodebin,data->sink,  NULL);

    if (!gst_element_link (data->source, data->decodebin))
    {
       g_printerr ("Elements could not be linked.\n");
    }
    else
    {
        //printf("link success---- \n");
    }


    if (!gst_element_link (data->videoconvert, data->sink))
    {
       g_printerr (" videoconvert Elements could not be linked.\n");
    }
    else
    {
        //printf("videoconvert link success---- \n");
    }


    data->bus = gst_element_get_bus (data->pipeline);

    /* Instruct the bus to emit signals for each received message, and connect to the interesting signals */
    gst_bus_add_signal_watch (data->bus);
    g_signal_connect (G_OBJECT (data->bus), "message::error", (GCallback)error_cb, data);
    g_signal_connect (G_OBJECT (data->bus), "message::eos", (GCallback)eos_cb, data);
    g_signal_connect (G_OBJECT (data->bus), "message::state-changed", (GCallback)state_changed_cb, data);
//    // g_signal_connect (G_OBJECT (bus), "message::application", (GCallback)application_cb, &data);

    g_signal_connect (data->decodebin, "pad-added", G_CALLBACK (pad_added_handler), data->videoconvert);


}

void mediaplayer::playerslot()
{

    g_winid[player_id] = ui->video->winId();

    dprintf("player_id = %d \n",player_id);

    pthread_create(&tid,NULL,startplayerthread, &player_id);

    dprintf("thread tid = %u \n",tid);

}

void mediaplayer::getvideo_urislot()
{
    QFileDialog *fd = new QFileDialog(this);
    fd->setWindowTitle("OpenVideo");
    fd->setModal(QFileDialog::ExistingFile);
    fd->setViewMode(QFileDialog::Detail);

    //fd->setFilter("Allfile(*.*);;mp3file(*.mp3);;wmafile(*.wma);;wavefile(*.wav)");     //Filer files


    if (fd->exec() == QDialog::Accepted)
    {
     // QString file = fd->selectedFiles()[0];  // Get detail filename and dir
       g_filename[player_id] = fd->selectedFiles()[0];

      dprintf("OpenMediaFile: %s\n",  fd->selectedFiles()[0].toUtf8().constData());

      delete fd;
    }
}

//WId xwinid = ui->video->winId();

void  *startplayerthread(void *id)
{
    int player_id = *(int *)id;

    g_thread_exit_flag[player_id] = false;   // Start thread

   createplayer(&g_data[player_id]);
  /* Set the URI to play */
    g_object_set (g_data[player_id].source, "location",g_filename[player_id].toUtf8().constData(), NULL);  //uri.toUtf8().constData()
   // g_object_set (data.source, "location","/mnt/nfs/30fps480p.mp4", NULL);

   //  g_object_set (g_data[player_id].sink, "create-window", FALSE, NULL);
    /*  Render and overlay video to Qwidget */
     gst_video_overlay_set_window_handle (GST_VIDEO_OVERLAY (g_data[player_id].sink), g_winid[player_id]);

    GstStateChangeReturn ret = gst_element_set_state (g_data[player_id].pipeline,GST_STATE_PLAYING);

    if (ret == GST_STATE_CHANGE_FAILURE)
    {
        g_printerr ("Unable to set the pipeline to the playing state.\n");
        gst_object_unref (g_data[player_id].pipeline);

    }
    while(g_thread_exit_flag[player_id] != true)
    {
        sleep(1);
    }

}

void mediaplayer::stopplayerslot()
{
    void *tret;
    dprintf("mediaplayer::stopplayer\n");
    g_thread_exit_flag[player_id] = true;

    if(g_data[player_id].bus != NULL)
    {
        gst_object_unref (g_data[player_id].bus);
        g_data[player_id].bus = NULL;
    }

    if( g_data[player_id].pipeline != NULL)
    {
       gst_element_set_state ( g_data[player_id].pipeline, GST_STATE_READY);
       gst_element_set_state ( g_data[player_id].pipeline, GST_STATE_NULL);
       gst_object_unref ( g_data[player_id].pipeline);
    }

    pthread_join(tid, &tret);  // Waitting thread tid exit


    dprintf("mediaplayer thread exit \n");


}

void mediaplayer::loopplayerslot()
{
    if(g_data[player_id].loop_player == false)
    {
        ui->loop->setText("cancle_loop");
        g_data[player_id].loop_player = true;
    }
    else
    {
          ui->loop->setText("loop_player");
        g_data[player_id].loop_player = false;
    }
}

