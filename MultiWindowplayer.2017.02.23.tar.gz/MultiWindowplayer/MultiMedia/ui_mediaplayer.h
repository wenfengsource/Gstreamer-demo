/********************************************************************************
** Form generated from reading UI file 'mediaplayer.ui'
**
** Created by: Qt User Interface Compiler version 5.2.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MEDIAPLAYER_H
#define UI_MEDIAPLAYER_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QFrame>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_mediaplayer
{
public:
    QPushButton *open;
    QPushButton *player;
    QPushButton *stop;
    QFrame *video;
    QPushButton *loop;
    QPushButton *pause;
    QCheckBox *SoftDec;

    void setupUi(QFrame *mediaplayer)
    {
        if (mediaplayer->objectName().isEmpty())
            mediaplayer->setObjectName(QStringLiteral("mediaplayer"));
        mediaplayer->resize(613, 368);
        mediaplayer->setStyleSheet(QStringLiteral("border-color: rgb(255, 0, 0);"));
        mediaplayer->setFrameShape(QFrame::StyledPanel);
        mediaplayer->setFrameShadow(QFrame::Raised);
        mediaplayer->setLineWidth(3);
        open = new QPushButton(mediaplayer);
        open->setObjectName(QStringLiteral("open"));
        open->setGeometry(QRect(0, 250, 71, 25));
        player = new QPushButton(mediaplayer);
        player->setObjectName(QStringLiteral("player"));
        player->setGeometry(QRect(114, 250, 81, 25));
        stop = new QPushButton(mediaplayer);
        stop->setObjectName(QStringLiteral("stop"));
        stop->setGeometry(QRect(210, 250, 85, 25));
        video = new QFrame(mediaplayer);
        video->setObjectName(QStringLiteral("video"));
        video->setGeometry(QRect(-1, -1, 581, 251));
        video->setStyleSheet(QStringLiteral("background-color: rgb(0, 0, 0);"));
        video->setFrameShape(QFrame::StyledPanel);
        video->setFrameShadow(QFrame::Raised);
        loop = new QPushButton(mediaplayer);
        loop->setObjectName(QStringLiteral("loop"));
        loop->setGeometry(QRect(390, 250, 85, 25));
        pause = new QPushButton(mediaplayer);
        pause->setObjectName(QStringLiteral("pause"));
        pause->setGeometry(QRect(300, 250, 85, 25));
        SoftDec = new QCheckBox(mediaplayer);
        SoftDec->setObjectName(QStringLiteral("SoftDec"));
        SoftDec->setGeometry(QRect(480, 250, 97, 22));

        retranslateUi(mediaplayer);

        QMetaObject::connectSlotsByName(mediaplayer);
    } // setupUi

    void retranslateUi(QFrame *mediaplayer)
    {
        mediaplayer->setWindowTitle(QApplication::translate("mediaplayer", "Frame", 0));
        open->setText(QApplication::translate("mediaplayer", "Open", 0));
        player->setText(QApplication::translate("mediaplayer", "player", 0));
        stop->setText(QApplication::translate("mediaplayer", "stop", 0));
        loop->setText(QApplication::translate("mediaplayer", "loop_player", 0));
        pause->setText(QApplication::translate("mediaplayer", "pause", 0));
        SoftDec->setText(QApplication::translate("mediaplayer", "SoftDec", 0));
    } // retranslateUi

};

namespace Ui {
    class mediaplayer: public Ui_mediaplayer {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MEDIAPLAYER_H
