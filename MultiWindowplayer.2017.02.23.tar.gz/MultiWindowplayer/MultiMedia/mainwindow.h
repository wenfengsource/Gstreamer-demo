#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include<qthread.h>

#include "mediaplayer.h"
#include "rtspplayer.h"
#include "axismulticastplayer.h"

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();
void showframe();

void CreateMediaPlayer();
void CreateRtspPlayer();
void CreateAxisMultiCastPlayer();


private slots:
    void playerrtspSlot();
    void playerlocalfileSlot();
    void playeraxismulticastpalyerSlot();

public:
    mediaplayer *pmediaplayer[4][4];
    rtspplayer  *prtspplayer[4][4];
    AxisMulticastPlayer *paxismulticastplayer[4][4];

private:
    bool m_localfileplayer;
    bool m_rtspplayer;
    bool m_axismulticastplayer;

    Ui::MainWindow *ui;
};

#endif // MAINWINDOW_H
