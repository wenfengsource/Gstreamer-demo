#include "rtspplayer.h"
#include "ui_rtspplayer.h"


static void error_cb (GstBus *bus, GstMessage *msg, CustomData *data);
static void eos_cb (GstBus *bus, GstMessage *msg, CustomData *data);
static void state_changed_cb (GstBus *bus, GstMessage *msg, CustomData *data);
static void pad_added_handler(GstElement *src, GstPad *new_pad, GstElement *sink);
static void pad_added_handler_for_rtsp (GstElement *src, GstPad *new_pad, GstElement *decode);

/* decode to nvglessink pad add and link */
static void pad_added_handler(GstElement *src, GstPad *new_pad, GstElement *sink)
{

     GstPad *sink_pad = gst_element_get_static_pad (sink, "sink");
     GstPadLinkReturn ret;
     GstCaps *new_pad_caps = NULL;
     GstStructure *new_pad_struct = NULL;
     const gchar *new_pad_type = NULL;

     g_print ("Received new pad '%s' from '%s':\n", GST_PAD_NAME (new_pad), GST_ELEMENT_NAME (src));

     /* If our converter is already linked, we have nothing to do here */
     if (gst_pad_is_linked (sink_pad)) {
       g_print ("  We are already linked. Ignoring.\n");
       goto exit;
     }

     /* Check the new pad's type */
     new_pad_caps = gst_pad_get_current_caps (new_pad);
   //  new_pad_caps = gst_pad_get_caps (new_pad);

     new_pad_struct = gst_caps_get_structure (new_pad_caps, 0);
     new_pad_type = gst_structure_get_name (new_pad_struct);
     if (!g_str_has_prefix (new_pad_type, "video/x-raw")) {
       g_print ("  It has type '%s' which is not video audio. Ignoring.\n", new_pad_type);
       goto exit;
     }

     /* Attempt the link */
     ret = gst_pad_link (new_pad, sink_pad);
     if (GST_PAD_LINK_FAILED (ret)) {
       g_print ("  Type is '%s' but link failed.\n", new_pad_type);
     } else {
       g_print ("  Link succeeded (type '%s').\n", new_pad_type);
     }

   exit:
     /* Unreference the new pad's caps, if we got them */
     if (new_pad_caps != NULL)
       gst_caps_unref (new_pad_caps);

     /* Unreference the sink pad */
     gst_object_unref (sink_pad);
}

/* This function is called when an error message is posted on the bus */
static void error_cb (GstBus *bus, GstMessage *msg, CustomData *data)
{
    GError *err;
    gchar *debug_info;

    /* Print error details on the screen */
    gst_message_parse_error (msg, &err, &debug_info);
    g_printerr ("Error received from element %s: %s\n", GST_OBJECT_NAME (msg->src), err->message);
    g_printerr ("Debugging information: %s\n", debug_info ? debug_info : "none");
    g_clear_error (&err);
    g_free (debug_info);

    /* Set the pipeline to READY (which stops playback) */
    gst_element_set_state (data->pipeline, GST_STATE_READY);
}


/* This function is called when an End-Of-Stream message is posted on the bus.
 * We just set the pipeline to READY (which stops playback) */
static void eos_cb (GstBus *bus, GstMessage *msg, CustomData *data)
{
    g_print ("End-Of-Stream reached.\n");

    gst_element_set_state (data->pipeline, GST_STATE_READY);

}

/* This function is called when the pipeline changes states. We use it to
 * keep track of the current state. */
static void state_changed_cb (GstBus *bus, GstMessage *msg, CustomData *data)
{
    GstState old_state, new_state, pending_state;
    gst_message_parse_state_changed (msg, &old_state, &new_state, &pending_state);
    if (GST_MESSAGE_SRC (msg) == GST_OBJECT (data->pipeline))
    {
         //  data->state = new_state;
        g_print ("State set to %s\n", gst_element_state_get_name (new_state));
        if (old_state == GST_STATE_READY && new_state == GST_STATE_PAUSED)
        {
          /* For extra responsiveness, we refresh the GUI as soon as we reach the PAUSED state */

        }
    }
}

/* This function will be called by the pad-added signal */
static void pad_added_handler_for_rtsp (GstElement *src, GstPad *new_pad, GstElement *decode)
{
  GstPad *sink_pad = gst_element_get_static_pad (decode,"sink");
  GstPadLinkReturn ret;
  GstCaps *new_pad_caps = NULL;

  const gchar *new_pad_type = NULL;

  g_print ("Received new pad '%s' from '%s':\n", GST_PAD_NAME (new_pad), GST_ELEMENT_NAME (src));

  /* If our converter is already linked, we have nothing to do here */
  if (gst_pad_is_linked (sink_pad)) {
    g_print ("  We are already linked. Ignoring.\n");
    goto exit;
  }

    if (!strncmp(GST_PAD_NAME (new_pad), "recv_rtp_src_0", 14))
    { // Video pad
         g_print (" video pad\n");
    }
    else
    {
        goto exit;
    }

  /* Attempt the link */
  ret = gst_pad_link (new_pad, sink_pad);
  if (GST_PAD_LINK_FAILED (ret)) {
    g_print ("  Type is '%s' but link failed.\n", new_pad_type);
  } else {
    g_print ("  Link succeeded (type '%s').\n", new_pad_type);
  }

exit:
  /* Unreference the new pad's caps, if we got them */
  if (new_pad_caps != NULL)
    gst_caps_unref (new_pad_caps);

  /* Unreference the sink pad */
  gst_object_unref (sink_pad);
}


rtspplayer::rtspplayer(QWidget *parent) :
    QFrame(parent),
    ui(new Ui::rtspplayer)
{
    ui->setupUi(this);
    data.pipeline = NULL;
    pipelinestate = GST_STATE_NULL;

    bus = NULL;
    connect(ui->player,SIGNAL(clicked()),this,SLOT(playerslot()));
    connect(ui->stop,SIGNAL(clicked()),this,SLOT(stopslot()));

    connect(ui->softdec,SIGNAL(stateChanged(int)),this,SLOT(NoRenderStateChangeslot(int)));

}


rtspplayer::~rtspplayer()
{

    if(bus != NULL)
    {
        gst_object_unref (bus);
        bus = NULL;
    }
    if(data.pipeline != NULL)
    {
        gst_element_set_state (data.pipeline, GST_STATE_NULL);

        pipelinestate = GST_STATE_NULL;

        gst_object_unref (data.pipeline);
        data.pipeline = NULL;
    }
    delete ui;
}

void rtspplayer::createplayer(bool softdec)
{
    gst_init(NULL,NULL);
    /* Create the elements */
    data.source = gst_element_factory_make ("rtspsrc", "source");
    data.rtph264depay = gst_element_factory_make ("rtph264depay", "rtph264depay");
    data.h264parse = gst_element_factory_make ("h264parse", "h264parse");


    if(softdec == true)
    {
         data.videoconvert = gst_element_factory_make ("videoconvert", "videoconvert");
         data.decode = gst_element_factory_make ("avdec_h264", "decode");   // soft decode
    }
    else
    {
         data.videoconvert = gst_element_factory_make ("nvvidconv", "videoconvert");
         data.decode = gst_element_factory_make ("omxh264dec", "decode"); // hardware accelercation decode
    }



    data.sink = gst_element_factory_make ("xvimagesink", "sink");


    /* Create the empty pipeline */
    data.pipeline = gst_pipeline_new ("test-pipeline");

    if (!data.pipeline || !data.source || !data.rtph264depay || !data.h264parse || !data.decode || !data.sink) {
       g_printerr ("Not all elements could be created.\n");
    //  return -1;
    }


    gst_bin_add_many (GST_BIN (data.pipeline), data.source,data.rtph264depay,data.h264parse,data.decode,data.videoconvert,data.sink,  NULL);

    if (!gst_element_link_many (data.rtph264depay,data.h264parse, data.decode ,data.videoconvert,data.sink)) {
     //  g_printerr ("Elements could not be linked.\n");
    }

    bus = gst_element_get_bus (data.pipeline);

    /* Instruct the bus to emit signals for each received message, and connect to the interesting signals */
    gst_bus_add_signal_watch (bus);
    g_signal_connect (G_OBJECT (bus), "message::error", (GCallback)error_cb, &data);
    g_signal_connect (G_OBJECT (bus), "message::eos", (GCallback)eos_cb, &data);
    g_signal_connect (G_OBJECT (bus), "message::state-changed", (GCallback)state_changed_cb, &data);
    // g_signal_connect (G_OBJECT (bus), "message::application", (GCallback)application_cb, &data);


    g_signal_connect (data.source, "pad-added", G_CALLBACK (pad_added_handler_for_rtsp), data.rtph264depay);
  //  g_signal_connect (data.decode, "pad-added", G_CALLBACK (pad_added_handler), data.sink);


}


void rtspplayer::showframe(QRect &rect)
{
    QSize b;

   //  rect.adjust(0,0,1920/2,1080/2);
  //  a.setHeight(1080/2);
  //  a.setWidth(1920/2);
    this->setGeometry(rect);

    //dprintf("a.width() = %d\n", rect.width());
   //dprintf("a.Hight() = %d\n", rect.height());

    b.setHeight(rect.height()-30);
    b.setWidth(rect.width());
    ui->video->resize(b);
    ui->label->setGeometry(0,rect.height()-25,30,25);
    ui->rtspurl->setGeometry(30, rect.height() - 25,120,25);
    ui->label_2->setGeometry(150, rect.height() - 25,20,25);
    ui->user_id->setGeometry(170,rect.height() - 25,45,25);
    ui->label_3->setGeometry(215,rect.height() - 25,20,25);
    ui->user_pw->setGeometry(235, rect.height() - 25,45,25);
    ui->softdec->setGeometry(280, rect.height() - 25,90,25);
    ui->player->setGeometry(370, rect.height() - 25,50,25);
    ui->stop->setGeometry(420, rect.height() - 25,50,25);


    this->show();

}

void rtspplayer::hide()
{
    ui->video->hide();
    ui->label->hide();
    ui->rtspurl->hide();
    ui->label_2->hide();
    ui->label_3->hide();
    ui->user_id->hide();
    ui->softdec->hide();
    ui->player->hide();
    ui->stop->hide();
    ui->user_pw->hide();
}

void rtspplayer::playerslot()
{
    rtsp_url = ui->rtspurl->text();
    user_id = ui->user_id->text();
    user_pw = ui->user_pw->text();


    dprintf("rtsp_url = %s\n", rtsp_url.toUtf8().constData());
    dprintf("user_id = %s\n", user_id.toUtf8().constData());

    if(ui->rtspurl->text() == NULL)
    {
        dprintf("please input correct rtsp url \n");
        return;
    }
    softdec_flag = ui->softdec->isChecked();
    createplayer(softdec_flag);

    /* Set the URI to play */
   // g_object_set (data.source, "location", "rtsp://192.168.0.55/axis-media/media.amp?videocodec=h264", NULL);
   // g_object_set (data.source, "user-id", "root", NULL);
   // g_object_set (data.source, "user-pw", "root", NULL);

    dprintf("---------\n");

    g_object_set (data.source, "location",rtsp_url.toUtf8().constData(), NULL);  //uri.toUtf8().constData()
    g_object_set (data.source, "user-id", user_id.toUtf8().constData(), NULL);
    g_object_set (data.source, "user-pw", user_pw.toUtf8().constData(), NULL);

    g_object_set (data.source, "latency",200,NULL);

    g_object_set (data.decode, "enable-error-check",true,NULL);


    if(softdec_flag != true)
    {
       // g_object_set (data.decode, "disable-dpb",true,NULL);  // decrease latency
    }

       // g_object_set (data.sink, "create-window", FALSE, NULL);


    WId xwinid = ui->video->winId();

    /*  Render and overlay video to Qwidget */
    gst_video_overlay_set_window_handle (GST_VIDEO_OVERLAY (data.sink), xwinid);



    GstStateChangeReturn ret = gst_element_set_state (data.pipeline,GST_STATE_PLAYING);

     pipelinestate = GST_STATE_PLAYING;


    if (ret == GST_STATE_CHANGE_FAILURE)
    {
        g_printerr ("Unable to set the pipeline to the playing state.\n");
        gst_object_unref (data.pipeline);
        data.pipeline = NULL;

    }
}

void rtspplayer::NoRenderStateChangeslot(int)
{
    if(pipelinestate != GST_STATE_NULL)
    {
      stopslot();
      playerslot();
    }
}


void rtspplayer::stopslot()
{
    if(bus != NULL)
    {
        gst_object_unref (bus);
        bus = NULL;
    }

    if(data.pipeline != NULL)
    {
        gst_element_set_state (data.pipeline, GST_STATE_NULL);

        pipelinestate = GST_STATE_NULL;

        gst_object_unref (data.pipeline);
        data.pipeline = NULL;
    }
}
