/********************************************************************************
** Form generated from reading UI file 'axismulticastplayer.ui'
**
** Created by: Qt User Interface Compiler version 5.2.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_AXISMULTICASTPLAYER_H
#define UI_AXISMULTICASTPLAYER_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QFrame>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_AxisMulticastPlayer
{
public:
    QLabel *label;
    QLineEdit *ipaddress;
    QLabel *label_2;
    QLineEdit *user_id;
    QLabel *label_3;
    QLineEdit *user_pw;
    QPushButton *player;
    QPushButton *stop;
    QFrame *video;

    void setupUi(QFrame *AxisMulticastPlayer)
    {
        if (AxisMulticastPlayer->objectName().isEmpty())
            AxisMulticastPlayer->setObjectName(QStringLiteral("AxisMulticastPlayer"));
        AxisMulticastPlayer->resize(701, 405);
        AxisMulticastPlayer->setFrameShape(QFrame::StyledPanel);
        AxisMulticastPlayer->setFrameShadow(QFrame::Raised);
        label = new QLabel(AxisMulticastPlayer);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(10, 370, 67, 17));
        ipaddress = new QLineEdit(AxisMulticastPlayer);
        ipaddress->setObjectName(QStringLiteral("ipaddress"));
        ipaddress->setGeometry(QRect(60, 370, 113, 27));
        label_2 = new QLabel(AxisMulticastPlayer);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(190, 370, 67, 17));
        user_id = new QLineEdit(AxisMulticastPlayer);
        user_id->setObjectName(QStringLiteral("user_id"));
        user_id->setGeometry(QRect(220, 370, 41, 27));
        label_3 = new QLabel(AxisMulticastPlayer);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(270, 380, 67, 17));
        user_pw = new QLineEdit(AxisMulticastPlayer);
        user_pw->setObjectName(QStringLiteral("user_pw"));
        user_pw->setGeometry(QRect(300, 370, 41, 27));
        player = new QPushButton(AxisMulticastPlayer);
        player->setObjectName(QStringLiteral("player"));
        player->setGeometry(QRect(410, 370, 99, 27));
        stop = new QPushButton(AxisMulticastPlayer);
        stop->setObjectName(QStringLiteral("stop"));
        stop->setGeometry(QRect(550, 370, 99, 27));
        video = new QFrame(AxisMulticastPlayer);
        video->setObjectName(QStringLiteral("video"));
        video->setGeometry(QRect(10, 0, 681, 351));
        video->setStyleSheet(QStringLiteral("background-color: rgb(0, 0, 0);"));
        video->setFrameShape(QFrame::StyledPanel);
        video->setFrameShadow(QFrame::Raised);

        retranslateUi(AxisMulticastPlayer);

        QMetaObject::connectSlotsByName(AxisMulticastPlayer);
    } // setupUi

    void retranslateUi(QFrame *AxisMulticastPlayer)
    {
        AxisMulticastPlayer->setWindowTitle(QApplication::translate("AxisMulticastPlayer", "Frame", 0));
        label->setText(QApplication::translate("AxisMulticastPlayer", "CamIP", 0));
        label_2->setText(QApplication::translate("AxisMulticastPlayer", "ID", 0));
        label_3->setText(QApplication::translate("AxisMulticastPlayer", "PW", 0));
        player->setText(QApplication::translate("AxisMulticastPlayer", "Player", 0));
        stop->setText(QApplication::translate("AxisMulticastPlayer", "Stop", 0));
    } // retranslateUi

};

namespace Ui {
    class AxisMulticastPlayer: public Ui_AxisMulticastPlayer {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_AXISMULTICASTPLAYER_H
