#ifndef AXISMULTICASTPLAYER_H
#define AXISMULTICASTPLAYER_H

#include <QFrame>
#include "defines.h"

namespace Ui {
class AxisMulticastPlayer;
}

class AxisMulticastPlayer : public QFrame
{
    Q_OBJECT

public:
    explicit AxisMulticastPlayer(QWidget *parent = 0);
    ~AxisMulticastPlayer();
    void showframe(QRect &rect);
    void createplayer();
    GstCustomData data;
    GstBus *bus;
    GstMessage *msg;
    GstStateChangeReturn ret;
    gboolean terminate;
    QString video_uri;


    QString multicast_url;
   // qint8 loop_player;

private:


public slots:

    void startplayerslot();
    void stopplayerslot();



private:
    Ui::AxisMulticastPlayer *ui;
};

#endif // AXISMULTICASTPLAYER_H
