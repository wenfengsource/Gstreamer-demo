#include "axismulticastplayer.h"
#include "ui_axismulticastplayer.h"


static void error_cb (GstBus *bus, GstMessage *msg, GstCustomData *data);
static void eos_cb (GstBus *bus, GstMessage *msg, GstCustomData *data);
static void state_changed_cb (GstBus *bus, GstMessage *msg, GstCustomData *data);
static void pad_added_handler(GstElement *src, GstPad *new_pad, GstElement *sink);


/* decodebin to nvglessink pad add and link */
static void pad_added_handler(GstElement *src, GstPad *new_pad, GstElement *sink)
{

     GstPad *sink_pad = gst_element_get_static_pad (sink, "sink");
     GstPadLinkReturn ret;
     GstCaps *new_pad_caps = NULL;
     GstStructure *new_pad_struct = NULL;
     const gchar *new_pad_type = NULL;

     g_print ("Received new pad '%s' from '%s':\n", GST_PAD_NAME (new_pad), GST_ELEMENT_NAME (src));

     /* If our converter is already linked, we have nothing to do here */
     if (gst_pad_is_linked (sink_pad)) {
       g_print ("  We are already linked. Ignoring.\n");
       goto exit;
     }

     /* Check the new pad's type */
     new_pad_caps = gst_pad_get_current_caps (new_pad);
   //  new_pad_caps = gst_pad_get_caps (new_pad);

     new_pad_struct = gst_caps_get_structure (new_pad_caps, 0);
     new_pad_type = gst_structure_get_name (new_pad_struct);
   //  if (!g_str_has_prefix (new_pad_type, "video/x-raw")) {
   //    g_print ("  It has type '%s' which is not video audio. Ignoring.\n", new_pad_type);
   //    goto exit;
  //   }

     /* Attempt the link */
     ret = gst_pad_link (new_pad, sink_pad);
     if (GST_PAD_LINK_FAILED (ret)) {
       g_print ("  Type is '%s' but link failed.\n", new_pad_type);
     } else {
       g_print ("  Link succeeded (type '%s').\n", new_pad_type);
     }

   exit:
     /* Unreference the new pad's caps, if we got them */
     if (new_pad_caps != NULL)
       gst_caps_unref (new_pad_caps);

     /* Unreference the sink pad */
     gst_object_unref (sink_pad);
}

/* This function is called when an error message is posted on the bus */
static void error_cb (GstBus *bus, GstMessage *msg, GstCustomData *data)
{
    GError *err;
    gchar *debug_info;

    /* Print error details on the screen */
    gst_message_parse_error (msg, &err, &debug_info);
    g_printerr ("Error received from element %s: %s\n", GST_OBJECT_NAME (msg->src), err->message);
    g_printerr ("Debugging information: %s\n", debug_info ? debug_info : "none");
    g_clear_error (&err);
    g_free (debug_info);

    /* Set the pipeline to READY (which stops playback) */
    gst_element_set_state (data->pipeline, GST_STATE_READY);
}


/* This function is called when an End-Of-Stream message is posted on the bus.
 * We just set the pipeline to READY (which stops playback) */
static void eos_cb (GstBus *bus, GstMessage *msg, GstCustomData *data)
{
    g_print ("End-Of-Stream reached.\n");
    if(data->loop_player == true)
    {
        gst_element_set_state (data->pipeline, GST_STATE_READY);
        usleep(1000);
        gst_element_set_state (data->pipeline,GST_STATE_PLAYING);
    }
    else
    {
        gst_element_set_state (data->pipeline, GST_STATE_READY);
    }
}

/* This function is called when the pipeline changes states. We use it to
 * keep track of the current state. */
static void state_changed_cb (GstBus *bus, GstMessage *msg, GstCustomData *data)
{
    GstState old_state, new_state, pending_state;
    gst_message_parse_state_changed (msg, &old_state, &new_state, &pending_state);
    if (GST_MESSAGE_SRC (msg) == GST_OBJECT (data->pipeline))
    {
         //  data->state = new_state;
        g_print ("State set to %s\n", gst_element_state_get_name (new_state));
        if (old_state == GST_STATE_READY && new_state == GST_STATE_PAUSED)
        {
          /* For extra responsiveness, we refresh the GUI as soon as we reach the PAUSED state */

        }
    }
}


AxisMulticastPlayer::AxisMulticastPlayer(QWidget *parent) :
    QFrame(parent),
    ui(new Ui::AxisMulticastPlayer)
{
    ui->setupUi(this);

    connect(ui->player, SIGNAL(clicked()), this, SLOT(startplayerslot()));
    connect(ui->stop, SIGNAL(clicked()), this, SLOT(stopplayerslot()));
    createplayer();
}

AxisMulticastPlayer::~AxisMulticastPlayer()
{

    gst_object_unref (bus);
    gst_element_set_state (data.pipeline, GST_STATE_NULL);
    gst_object_unref (data.pipeline);

    delete ui;
}

void AxisMulticastPlayer::startplayerslot()
{
   // Get sdp file

    multicast_url = "./curl -o /tmp/axismulticast.sdp -u " + ui->user_id->text()+":"+ ui->user_pw->text()+ " http://" + ui->ipaddress->text() + "/axis-cgi/alwaysmulti.sdp?camera=1";

    dprintf("multicast_url =%s\n", multicast_url.toUtf8().constData());
    //system("curl -o /tmp/axismulticast.sdp -u root:root 192.168.0.103/axis-cgi/alwaysmulti.sdp?camera=1");
    system(multicast_url.toUtf8().constData());


    /* Set the URI to play */
    g_object_set (data.source, "location","/tmp/axismulticast.sdp", NULL);  //uri.toUtf8().constData()


  // g_object_set (data.sink, "create-window", FALSE, NULL);


    WId xwinid = ui->video->winId();

    /*  Render and overlay video to Qwidget */
    gst_video_overlay_set_window_handle (GST_VIDEO_OVERLAY (data.sink), xwinid);

    GstStateChangeReturn ret = gst_element_set_state (data.pipeline,GST_STATE_PLAYING);

    if (ret == GST_STATE_CHANGE_FAILURE)
    {
        g_printerr ("Unable to set the pipeline to the playing state.\n");
        gst_object_unref (data.pipeline);

    }

}

void AxisMulticastPlayer::stopplayerslot()
{
    dprintf("mediaplayer::stopplayer");
    data.loop_player = false;
    gst_element_set_state (data.pipeline, GST_STATE_READY);

}



void AxisMulticastPlayer::showframe(QRect &rect)
{
    QSize b;

   //  rect.adjust(0,0,1920/2,1080/2);
  //  a.setHeight(1080/2);
  //  a.setWidth(1920/2);
    this->setGeometry(rect);

    //dprintf("a.width() = %d\n", rect.width());
   //dprintf("a.Hight() = %d\n", rect.height());

    b.setHeight(rect.height()-30);
    b.setWidth(rect.width());
    ui->video->resize(b);
    ui->label->setGeometry(0,rect.height()-25,50,25);
    ui->ipaddress->setGeometry(50, rect.height() - 25,120,25);
    ui->label_2->setGeometry(170, rect.height() - 25,20,25);
    ui->user_id->setGeometry(190,rect.height() - 25,45,25);
    ui->label_3->setGeometry(235,rect.height() - 25,20,25);
    ui->user_pw->setGeometry(265, rect.height() - 25,45,25);

    ui->player->setGeometry(370, rect.height() - 25,50,25);
    ui->stop->setGeometry(420, rect.height() - 25,50,25);


    this->show();

}

/* filesrc -> decodebin -> nveglglessink  */
void AxisMulticastPlayer::createplayer()
{
    gst_init(NULL,NULL);
    /* Create the elements */
    data.source = gst_element_factory_make ("filesrc", "source");
    data.sdpdemux= gst_element_factory_make ("sdpdemux", "sdpdemux");
    data.decodebin = gst_element_factory_make ("decodebin", "decodebin");
    data.sink = gst_element_factory_make ("nveglglessink", "sink");

    /* Create the empty pipeline */
    data.pipeline = gst_pipeline_new ("test-pipeline");

    if (!data.pipeline || !data.source || !data.sink) {
    g_printerr ("Not all elements could be created.\n");
    //  return -1;
    }


    gst_bin_add_many (GST_BIN (data.pipeline), data.source,data.sdpdemux,data.decodebin,data.sink,  NULL);

    if (!gst_element_link (data.source, data.sdpdemux))
    {
       g_printerr ("Elements could not be linked.\n");
    }
    else
    {
        //printf("link success---- \n");
    }

    bus = gst_element_get_bus (data.pipeline);

    /* Instruct the bus to emit signals for each received message, and connect to the interesting signals */
    gst_bus_add_signal_watch (bus);
    g_signal_connect (G_OBJECT (bus), "message::error", (GCallback)error_cb, &data);
    g_signal_connect (G_OBJECT (bus), "message::eos", (GCallback)eos_cb, &data);
    g_signal_connect (G_OBJECT (bus), "message::state-changed", (GCallback)state_changed_cb, &data);
    // g_signal_connect (G_OBJECT (bus), "message::application", (GCallback)application_cb, &data);

    g_signal_connect (data.sdpdemux, "pad-added", G_CALLBACK (pad_added_handler), data.decodebin);

    g_signal_connect (data.decodebin, "pad-added", G_CALLBACK (pad_added_handler), data.sink);


}

