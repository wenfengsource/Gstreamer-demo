#ifndef MEDIAPLAYER_H
#define MEDIAPLAYER_H

#include <QFrame>
#include<QThread>
#include "mediaplayer.h"
#include "defines.h"


namespace Ui {
class mediaplayer;
}

class mediaplayer : public QFrame
{
    Q_OBJECT

public:
    explicit mediaplayer(QWidget *parent = 0);
    ~mediaplayer();

    void showframe(QRect &rect);
    void setplayer_id(int id);
 //   void createplayer();


public:


    WId winid ;





private:
    pthread_t tid;
    int player_id;

public slots:
     void playerslot();
      void stopplayerslot();
      void getvideo_urislot();
      void loopplayerslot();

private:
    Ui::mediaplayer *ui;
};

#endif // MEDIAPLAYER_H
