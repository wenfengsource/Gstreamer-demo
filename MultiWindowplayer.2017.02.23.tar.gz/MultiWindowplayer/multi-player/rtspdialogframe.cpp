#include "rtspdialogframe.h"
#include "ui_rtspdialogframe.h"
#include <QFileDialog>
#include<qfiledialog.h>
rtspdialogframe::rtspdialogframe(QWidget *parent) :
    QFrame(parent),
    ui(new Ui::rtspdialogframe)
{
    ui->setupUi(this);
    connect(ui->OK, SIGNAL(clicked()), this, SLOT(buttonokslot()));
    connect(ui->CANCLE, SIGNAL(clicked()), this, SLOT(buttonCancleslot()));

    connect(ui->Load,SIGNAL(clicked()),this,SLOT(buttonloadslot()));


    this->setWindowFlags( Qt::WindowStaysOnTopHint | Qt::Tool | Qt::CustomizeWindowHint | Qt::WindowTitleHint);


}

rtspdialogframe::~rtspdialogframe()
{
    dprintf("~rtspdialogframe \n");
    delete ui;
}

void rtspdialogframe::buttonokslot()
{
     savecamerainfo();
    emit rtspdialogOKsignal();

}

void rtspdialogframe::buttonCancleslot()
{
     delete this;
}

QString rtspdialogframe::getrtspaddress()
{
    return ui->rtspaddress->text();
}

QString rtspdialogframe::getuser_name()
{
    return ui->user_name->text();
}

QString rtspdialogframe::getuser_password()
{
    return ui->password->text();
}

void rtspdialogframe::savecamerainfo()
{
    QFile CameraInfoFile("./camerainfo.xml");
    if(!CameraInfoFile.open(QFile::WriteOnly | QFile::Text))
    {

    }
    camerainfowriter TempCamerainfowriter;
    CAMERAINFO camerainfo;
    camerainfo.rtsp_address = ui->rtspaddress->text();
    camerainfo.user_name = ui->user_name->text();
    camerainfo.user_pw = ui->password->text();

    TempCamerainfowriter.WriteFile(&CameraInfoFile, &camerainfo);

    CameraInfoFile.close();
    dprintf("Save camera info \n");
}

void rtspdialogframe::buttonloadslot()
{
    QFileDialog *fd = new QFileDialog(this);
    fd->setWindowTitle("OpenVideo");
    fd->setModal(QFileDialog::ExistingFile);
    fd->setViewMode(QFileDialog::Detail);
    fd->setDirectory(".");



   fd->setNameFilter("camera*.xml");


    if (fd->exec() == QDialog::Accepted)
    {
        // QString file = fd->selectedFiles()[0];  // Get detail filename and dir
        //  g_filename[player_id] = fd->selectedFiles()[0];

        dprintf("OpenMediaFile: %s\n",  fd->selectedFiles()[0].toUtf8().constData());

        loadcamerainfo( fd->selectedFiles()[0].toUtf8().constData());
    }

}

void rtspdialogframe::loadcamerainfo(QString str)
{
     QFile  CameraInfoFile(str);
     if(!CameraInfoFile.open(QFile::ReadOnly | QFile::Text))
     {
         dprintf("Error Read CameraInfoFile \n");
     }
     Camerainforeader TempCamerainforeader;
     CAMERAINFO camerainfo;

     if(!TempCamerainforeader.ReadCameraInfo(&CameraInfoFile,&camerainfo))
     {
         dprintf("Error get CameraInfoFile \n");
     }

     CameraInfoFile.close();

     ui->rtspaddress->setText(camerainfo.rtsp_address);
     ui->user_name->setText(camerainfo.user_name);
     ui->password->setText(camerainfo.user_pw);
}









