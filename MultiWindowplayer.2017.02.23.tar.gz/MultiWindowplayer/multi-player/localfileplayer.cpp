#include "localfileplayer.h"



/* decodebin to videoconvert pad add and link */
static void pad_added_handler(GstElement *src, GstPad *new_pad, GstElement *sink)
{

     GstPad *sink_pad = gst_element_get_static_pad (sink, "sink");
     GstPadLinkReturn ret;
     GstCaps *new_pad_caps = NULL;
     GstStructure *new_pad_struct = NULL;
     const gchar *new_pad_type = NULL;

     g_print ("Received new pad '%s' from '%s':\n", GST_PAD_NAME (new_pad), GST_ELEMENT_NAME (src));

     /* If our converter is already linked, we have nothing to do here */
     if (gst_pad_is_linked (sink_pad)) {
       g_print ("  We are already linked. Ignoring.\n");
       goto exit;
     }

     /* Check the new pad's type */
     new_pad_caps = gst_pad_get_current_caps (new_pad);
   //  new_pad_caps = gst_pad_get_caps (new_pad);

     new_pad_struct = gst_caps_get_structure (new_pad_caps, 0);
     new_pad_type = gst_structure_get_name (new_pad_struct);
     if (!g_str_has_prefix (new_pad_type, "video/x-raw")) {
       g_print ("  It has type '%s' which is not video audio. Ignoring.\n", new_pad_type);
       goto exit;
     }

     /* Attempt the link */
     ret = gst_pad_link (new_pad, sink_pad);
     if (GST_PAD_LINK_FAILED (ret)) {
       g_print ("  Type is '%s' but link failed.\n", new_pad_type);
     } else {
       g_print ("  Link succeeded (type '%s').\n", new_pad_type);
     }

   exit:
     /* Unreference the new pad's caps, if we got them */
     if (new_pad_caps != NULL)
       gst_caps_unref (new_pad_caps);

     /* Unreference the sink pad */
     gst_object_unref (sink_pad);
}

/* This function is called when the pipeline changes states. We use it to
 * keep track of the current state. */
static void state_changed_cb (GstBus *bus, GstMessage *msg, fileplayerCustomData *data)
{
    GstState old_state, new_state, pending_state;
    gst_message_parse_state_changed (msg, &old_state, &new_state, &pending_state);
    if (GST_MESSAGE_SRC (msg) == GST_OBJECT (data->pipeline))
    {
         data->current_state = new_state;
        g_print ("State set to %s\n", gst_element_state_get_name (new_state));
        if (old_state == GST_STATE_READY && new_state == GST_STATE_PAUSED)
        {
          /* For extra responsiveness, we refresh the GUI as soon as we reach the PAUSED state */

        }
    }
}


localfileplayer::localfileplayer()
{

}

localfileplayer::~localfileplayer()
{
    if(gstdata.pipeline != NULL)
    {
       gst_element_set_state (gstdata.pipeline, GST_STATE_NULL);

       gst_object_unref (gstdata.pipeline);
       gstdata.pipeline = NULL;
    }
    if(gstdata.bus != NULL)
    {
       gst_object_unref (gstdata.bus);
       gstdata.bus = NULL;
    }
}


/* filesrc -> decodebin -> nveglglessink  */
void localfileplayer::createpipeline(WId id)
{
    //GstCustomData data = *pdata;
    gst_init(NULL,NULL);
    /* Create the elements */
    gstdata.source = gst_element_factory_make ("filesrc", "source");
    gstdata.decode = gst_element_factory_make ("decodebin", "decodebin");
    gstdata.videosink = gst_element_factory_make ("xvimagesink", "sink");
    gstdata.videoconvert = gst_element_factory_make ("nvvidconv", "videoconvert");

    /* Create the empty pipeline */
    gstdata.pipeline = gst_pipeline_new ("test-pipeline");

    if (!gstdata.pipeline || !gstdata.source  || !gstdata.decode || !gstdata.videoconvert || !gstdata.videosink)
    {
        g_printerr ("Not all elements could be created.\n");
        return ;
    }


    gst_bin_add_many (GST_BIN (gstdata.pipeline), gstdata.source,gstdata.decode,gstdata.videoconvert,gstdata.videosink,  NULL);



    if (!gst_element_link (gstdata.source, gstdata.decode))
    {
       g_printerr ("Elements could not be linked.\n");
    }
    else
    {
        //printf("link success---- \n");
    }


    if (!gst_element_link (gstdata.videoconvert, gstdata.videosink))
    {
       g_printerr (" videoconvert Elements could not be linked.\n");
    }
    else
    {
        //printf("videoconvert link success---- \n");
    }


    gstdata.bus = gst_element_get_bus (gstdata.pipeline);

    /* Instruct the bus to emit signals for each received message, and connect to the interesting signals */
    gst_bus_add_signal_watch (gstdata.bus);
    g_signal_connect (G_OBJECT (gstdata.bus), "message::error", (GCallback)error_cb, gstdata.pipeline);
    g_signal_connect (G_OBJECT (gstdata.bus), "message::eos", (GCallback)eos_cb, gstdata.pipeline);
    g_signal_connect (G_OBJECT (gstdata.bus), "message::state-changed", (GCallback)state_changed_cb, &gstdata);
//    // g_signal_connect (G_OBJECT (bus), "message::application", (GCallback)application_cb, &data);

    g_signal_connect (gstdata.decode, "pad-added", GCallback (pad_added_handler), gstdata.videoconvert);



    g_object_set (gstdata.source, "location",file_url.toUtf8().constData(), NULL);  //uri.toUtf8().constData()


    gst_video_overlay_set_window_handle (GST_VIDEO_OVERLAY (gstdata.videosink), id);


}

void localfileplayer::startplay()
{
    GstState st1;
    GstState st2;

    GstStateChangeReturn status = gst_element_set_state(GST_ELEMENT(gstdata.pipeline), GST_STATE_PLAYING);
    if (status == GST_STATE_CHANGE_ASYNC)
    {
       // wait for status update
        status = gst_element_get_state(gstdata.pipeline, &st1, &st2, GST_CLOCK_TIME_NONE);
    }
    if (status == GST_STATE_CHANGE_FAILURE)
    {
       // handleMessage(pipeline);
        gst_object_unref(gstdata.pipeline);
        gstdata.pipeline = NULL;

        dprintf("GST_STATE_CHANGE_FAILURE\n");
        return;
    }

    gstdata.current_state = GST_STATE_PLAYING;
    dprintf("state now playing\n");
}

void localfileplayer::pause()
{
    GstState st1;
    GstState st2;

    dprintf("localfileplayer::pause \n")
   // gst_element_set_state (gstdata.pipeline,GST_STATE_PAUSED);

    GstStateChangeReturn status = gst_element_set_state(GST_ELEMENT(gstdata.pipeline), GST_STATE_PAUSED);
    if (status == GST_STATE_CHANGE_ASYNC)
    {
        // wait for status update

        status = gst_element_get_state(gstdata.pipeline, &st1, &st2, GST_CLOCK_TIME_NONE);
    }
    if (status == GST_STATE_CHANGE_FAILURE)
    {

        gst_object_unref(gstdata.pipeline);
        gstdata.pipeline = NULL;

        dprintf("GST_STATE_CHANGE_FAILURE\n");
        return;
    }
    gstdata.current_state = GST_STATE_PAUSED;
}

void localfileplayer::stop()
{
    GstState st1;
    GstState st2;

    dprintf("rtspplayer::pause \n")

    GstStateChangeReturn status = gst_element_set_state(GST_ELEMENT(gstdata.pipeline), GST_STATE_READY);
    if (status == GST_STATE_CHANGE_ASYNC)
    {
        // wait for status update

        status = gst_element_get_state(gstdata.pipeline, &st1, &st2, GST_CLOCK_TIME_NONE);
    }
    if (status == GST_STATE_CHANGE_FAILURE)
    {
       // handleMessage(pipeline);
        gst_object_unref(gstdata.pipeline);
        gstdata.pipeline = NULL;

        dprintf("GST_STATE_CHANGE_FAILURE\n");
        return;
    }
    dprintf("current state = %d\n", st1);
    gstdata.current_state = GST_STATE_READY;

}


void localfileplayer::set_url(QString url)
{
    file_url = url;
}

void localfileplayer::set_user_name(QString name)
{

}

void localfileplayer::set_user_password(QString password)
{

}

void localfileplayer::record()
{

}

void localfileplayer::hide()
{

}

void localfileplayer::imageprocess(bool flag)
{

}

GstState localfileplayer::get_current_state()
{
    return gstdata.current_state;
}
