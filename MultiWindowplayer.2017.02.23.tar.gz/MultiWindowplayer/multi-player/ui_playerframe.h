/********************************************************************************
** Form generated from reading UI file 'playerframe.ui'
**
** Created by: Qt User Interface Compiler version 5.2.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_PLAYERFRAME_H
#define UI_PLAYERFRAME_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QFrame>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_playerframe
{
public:
    QFrame *video;
    QPushButton *open;
    QPushButton *play;
    QPushButton *stop;
    QPushButton *pause;
    QCheckBox *Record;
    QPushButton *imageprocess;

    void setupUi(QFrame *playerframe)
    {
        if (playerframe->objectName().isEmpty())
            playerframe->setObjectName(QStringLiteral("playerframe"));
        playerframe->resize(850, 484);
        playerframe->setFrameShape(QFrame::StyledPanel);
        playerframe->setFrameShadow(QFrame::Raised);
        video = new QFrame(playerframe);
        video->setObjectName(QStringLiteral("video"));
        video->setGeometry(QRect(0, 0, 851, 361));
        video->setStyleSheet(QLatin1String("color: rgb(0, 0, 0);\n"
"background-color: rgb(0, 0, 0);"));
        video->setFrameShape(QFrame::StyledPanel);
        video->setFrameShadow(QFrame::Raised);
        open = new QPushButton(playerframe);
        open->setObjectName(QStringLiteral("open"));
        open->setGeometry(QRect(10, 450, 99, 27));
        play = new QPushButton(playerframe);
        play->setObjectName(QStringLiteral("play"));
        play->setGeometry(QRect(130, 450, 99, 27));
        stop = new QPushButton(playerframe);
        stop->setObjectName(QStringLiteral("stop"));
        stop->setGeometry(QRect(360, 450, 99, 27));
        pause = new QPushButton(playerframe);
        pause->setObjectName(QStringLiteral("pause"));
        pause->setGeometry(QRect(250, 450, 99, 27));
        Record = new QCheckBox(playerframe);
        Record->setObjectName(QStringLiteral("Record"));
        Record->setGeometry(QRect(490, 450, 97, 22));
        imageprocess = new QPushButton(playerframe);
        imageprocess->setObjectName(QStringLiteral("imageprocess"));
        imageprocess->setGeometry(QRect(600, 450, 121, 27));

        retranslateUi(playerframe);

        QMetaObject::connectSlotsByName(playerframe);
    } // setupUi

    void retranslateUi(QFrame *playerframe)
    {
        playerframe->setWindowTitle(QApplication::translate("playerframe", "Frame", 0));
        open->setText(QApplication::translate("playerframe", "Open", 0));
        play->setText(QApplication::translate("playerframe", "Play", 0));
        stop->setText(QApplication::translate("playerframe", "Stop", 0));
        pause->setText(QApplication::translate("playerframe", "Pause", 0));
        Record->setText(QApplication::translate("playerframe", "Record", 0));
        imageprocess->setText(QApplication::translate("playerframe", "image config", 0));
    } // retranslateUi

};

namespace Ui {
    class playerframe: public Ui_playerframe {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_PLAYERFRAME_H
