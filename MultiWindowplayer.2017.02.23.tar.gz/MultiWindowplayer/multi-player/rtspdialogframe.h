#ifndef RTSPDIALOGFRAME_H
#define RTSPDIALOGFRAME_H

#include <qfile.h>
#include "defines.h"
#include "camerainforeader.h"
#include "camerainfowriter.h"

#include <QFrame>

namespace Ui {
class rtspdialogframe;
}

class rtspdialogframe : public QFrame
{
    Q_OBJECT

public:
    explicit rtspdialogframe(QWidget *parent = 0);
    ~rtspdialogframe();

    QString getrtspaddress();
    QString getuser_name();
    QString getuser_password();
    void savecamerainfo();
    void loadcamerainfo(QString str);


signals:
   void rtspdialogOKsignal();

private slots:
   void buttonokslot();
   void buttonCancleslot();
   void buttonloadslot();
private:
    Ui::rtspdialogframe *ui;
};

#endif // RTSPDIALOGFRAME_H
