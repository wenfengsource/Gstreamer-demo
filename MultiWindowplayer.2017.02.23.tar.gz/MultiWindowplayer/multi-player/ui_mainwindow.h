/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.2.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralWidget;
    QPushButton *layout1win;
    QPushButton *layout4win;
    QPushButton *layout16win;
    QPushButton *layout9win;
    QPushButton *FullScreen;
    QMenuBar *menuBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QStringLiteral("MainWindow"));
        MainWindow->resize(1920, 1080);
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        layout1win = new QPushButton(centralWidget);
        layout1win->setObjectName(QStringLiteral("layout1win"));
        layout1win->setGeometry(QRect(170, 0, 99, 30));
        layout4win = new QPushButton(centralWidget);
        layout4win->setObjectName(QStringLiteral("layout4win"));
        layout4win->setGeometry(QRect(300, 0, 99, 30));
        layout16win = new QPushButton(centralWidget);
        layout16win->setObjectName(QStringLiteral("layout16win"));
        layout16win->setGeometry(QRect(600, 0, 99, 30));
        layout9win = new QPushButton(centralWidget);
        layout9win->setObjectName(QStringLiteral("layout9win"));
        layout9win->setGeometry(QRect(450, 0, 99, 30));
        FullScreen = new QPushButton(centralWidget);
        FullScreen->setObjectName(QStringLiteral("FullScreen"));
        FullScreen->setGeometry(QRect(50, 0, 99, 30));
        MainWindow->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(MainWindow);
        menuBar->setObjectName(QStringLiteral("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 1920, 25));
        MainWindow->setMenuBar(menuBar);
        statusBar = new QStatusBar(MainWindow);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        MainWindow->setStatusBar(statusBar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "Multi-Player", 0));
        layout1win->setText(QApplication::translate("MainWindow", "Layout1", 0));
        layout4win->setText(QApplication::translate("MainWindow", "Layout4", 0));
        layout16win->setText(QApplication::translate("MainWindow", "Layout16", 0));
        layout9win->setText(QApplication::translate("MainWindow", "Layout9", 0));
        FullScreen->setText(QApplication::translate("MainWindow", "Full", 0));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
