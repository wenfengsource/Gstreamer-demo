/********************************************************************************
** Form generated from reading UI file 'imageprocessframe.ui'
**
** Created by: Qt User Interface Compiler version 5.2.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_IMAGEPROCESSFRAME_H
#define UI_IMAGEPROCESSFRAME_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QFrame>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>

QT_BEGIN_NAMESPACE

class Ui_ImageProcessframe
{
public:
    QPushButton *OK;
    QCheckBox *GPU;
    QRadioButton *Facedetection;
    QRadioButton *Hog;
    QRadioButton *Mosaic;
    QRadioButton *NULL_2;
    QLineEdit *MosaicScale;
    QLabel *label;

    void setupUi(QFrame *ImageProcessframe)
    {
        if (ImageProcessframe->objectName().isEmpty())
            ImageProcessframe->setObjectName(QStringLiteral("ImageProcessframe"));
        ImageProcessframe->resize(478, 280);
        ImageProcessframe->setStyleSheet(QStringLiteral("background-color: rgb(200, 200, 200);"));
        ImageProcessframe->setFrameShape(QFrame::StyledPanel);
        ImageProcessframe->setFrameShadow(QFrame::Raised);
        OK = new QPushButton(ImageProcessframe);
        OK->setObjectName(QStringLiteral("OK"));
        OK->setGeometry(QRect(300, 220, 99, 27));
        GPU = new QCheckBox(ImageProcessframe);
        GPU->setObjectName(QStringLiteral("GPU"));
        GPU->setGeometry(QRect(310, 130, 97, 22));
        Facedetection = new QRadioButton(ImageProcessframe);
        Facedetection->setObjectName(QStringLiteral("Facedetection"));
        Facedetection->setGeometry(QRect(40, 20, 141, 22));
        Facedetection->setCheckable(true);
        Facedetection->setChecked(true);
        Hog = new QRadioButton(ImageProcessframe);
        Hog->setObjectName(QStringLiteral("Hog"));
        Hog->setEnabled(true);
        Hog->setGeometry(QRect(40, 140, 117, 22));
        Hog->setChecked(false);
        Mosaic = new QRadioButton(ImageProcessframe);
        Mosaic->setObjectName(QStringLiteral("Mosaic"));
        Mosaic->setGeometry(QRect(40, 80, 117, 22));
        Mosaic->setChecked(false);
        NULL_2 = new QRadioButton(ImageProcessframe);
        NULL_2->setObjectName(QStringLiteral("NULL_2"));
        NULL_2->setEnabled(true);
        NULL_2->setGeometry(QRect(40, 190, 117, 22));
        NULL_2->setCheckable(true);
        NULL_2->setChecked(false);
        MosaicScale = new QLineEdit(ImageProcessframe);
        MosaicScale->setObjectName(QStringLiteral("MosaicScale"));
        MosaicScale->setGeometry(QRect(170, 80, 51, 27));
        label = new QLabel(ImageProcessframe);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(240, 80, 161, 17));

        retranslateUi(ImageProcessframe);

        QMetaObject::connectSlotsByName(ImageProcessframe);
    } // setupUi

    void retranslateUi(QFrame *ImageProcessframe)
    {
        ImageProcessframe->setWindowTitle(QApplication::translate("ImageProcessframe", "Frame", 0));
        OK->setText(QApplication::translate("ImageProcessframe", "OK", 0));
        GPU->setText(QApplication::translate("ImageProcessframe", "GPU", 0));
        Facedetection->setText(QApplication::translate("ImageProcessframe", "Facedetection", 0));
        Hog->setText(QApplication::translate("ImageProcessframe", "Hog", 0));
        Mosaic->setText(QApplication::translate("ImageProcessframe", "Mosaic", 0));
        NULL_2->setText(QApplication::translate("ImageProcessframe", "NULL", 0));
        MosaicScale->setText(QApplication::translate("ImageProcessframe", "1.5", 0));
        label->setText(QApplication::translate("ImageProcessframe", "ScaleFactor(0.5~2.5)", 0));
    } // retranslateUi

};

namespace Ui {
    class ImageProcessframe: public Ui_ImageProcessframe {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_IMAGEPROCESSFRAME_H
