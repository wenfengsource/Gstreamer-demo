#ifndef IMAGEPROCESSFRAME_H
#define IMAGEPROCESSFRAME_H

#include <QFrame>
#include "defines.h"

namespace Ui {
class ImageProcessframe;
}

enum ImageProcessType
{
    DO_NOTHING = 0,
    FACE_DETECTION,
    MOSAIC,
    HOG

};

class ImageProcessframe : public QFrame
{
    Q_OBJECT

public:
    explicit ImageProcessframe(QWidget *parent = 0);
    ~ImageProcessframe();


 signals:
    void imageporcess();

public:
    ImageProcessType m_ImageProcessType;
    bool  useGPU;
    bool  maskface;
    bool imageprocess_flag;
    float GetMosaicScaleFactor();

private:

   bool pre_imageporcess_flag;
        float MosaicScale;
private slots:

     void OKslot();
     void Clearslot();

private:
    Ui::ImageProcessframe *ui;
};

#endif // IMAGEPROCESSFRAME_H
