#include "imageprocessframe.h"
#include "ui_imageprocessframe.h"

ImageProcessframe::ImageProcessframe(QWidget *parent) :
    QFrame(parent),
    ui(new Ui::ImageProcessframe)
{
    ui->setupUi(this);

    connect(ui->OK, SIGNAL(clicked()), this, SLOT(OKslot()));
    // connect(ui->clear, SIGNAL(clicked()), this, SLOT(Clearslot()));

   ui->Hog->setEnabled(false);
   //ui->Mosaic->setEnabled(false); //wtb comment
  //   ui->NULL_2->setEnabled(false);

    m_ImageProcessType = DO_NOTHING;
    ui->NULL_2->setChecked(true);
    imageprocess_flag = false;
}

ImageProcessframe::~ImageProcessframe()
{
    delete ui;
}





void ImageProcessframe::OKslot()
{

   // static ImageProcessType Pre_ImageProcessType;

    useGPU = ui->GPU->isChecked();
    maskface = ui->Mosaic->isChecked();

    if(ui->Facedetection->isChecked())
    {
        m_ImageProcessType = FACE_DETECTION;
        imageprocess_flag = true;
    }
    else if(ui->Hog->isChecked())
    {
        m_ImageProcessType = HOG;
        imageprocess_flag = true;
    }
    else if(ui->Mosaic->isChecked())
    {
        m_ImageProcessType = MOSAIC;
        imageprocess_flag = true;
    }
    else
    {
        m_ImageProcessType = DO_NOTHING;
        imageprocess_flag = false;
    }

    if(pre_imageporcess_flag != imageprocess_flag)
    {
        pre_imageporcess_flag = imageprocess_flag;
         emit imageporcess();

    }



    MosaicScale = ui->MosaicScale->text().toFloat();
    dprintf("m_ImageProcessType =%d , Gpu_enable_flag = %d\n",m_ImageProcessType, useGPU);

    this->hide();

}

float ImageProcessframe::GetMosaicScaleFactor()
{
    return MosaicScale;
}

void ImageProcessframe::Clearslot()
{
    dprintf("ImageProcessframe::Clearslot\n");
  //  ui->Facedetection->setCheckable(false);
  //  ui->Hog->setChecked(false);
    // ui->Mosaic->setChecked(false);


}
