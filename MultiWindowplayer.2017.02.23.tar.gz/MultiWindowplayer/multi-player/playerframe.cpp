#include "playerframe.h"
#include "ui_playerframe.h"
#include <QFileDialog>



playerframe::playerframe(QWidget *parent) :
    QFrame(parent),
    ui(new Ui::playerframe)
{
    ui->setupUi(this);


    m_ImageProcessframe.setParent(this);
    m_ImageProcessframe.setVisible(false);
    connect( ui->play, SIGNAL(clicked()), this, SLOT(playslot()));
    connect( ui->stop, SIGNAL(clicked()), this, SLOT(stopslot()));
    connect( ui->pause, SIGNAL(clicked()), this, SLOT(pauseslot()));

    connect( ui->imageprocess, SIGNAL(clicked()), this, SLOT(imageprocessconfigslot()));

    connect(&m_ImageProcessframe,SIGNAL(imageporcess()), this, SLOT(imageprocessSlot()));

    pmediapalyer = NULL;
    localfile = NULL;
    rtsp = NULL;
    axismulticast = NULL;

    // Add menu for open button
    addmenu();
    ui->open->setMenu(&openmenu);

}



playerframe::~playerframe()
{
    if(pmediapalyer != NULL)
    {
        delete pmediapalyer;
    }
    if(rtsp != NULL)
    {
        delete rtsp;
    }
    if(localfile != NULL)
    {
        delete localfile;
    }
    if(axismulticast != NULL)
    {
        delete axismulticast;
    }
    delete ui;
}


void playerframe::showframe(QRect &rect, bool fullscreenflag)
{
    QSize b;

    this->setGeometry(rect);

    if(fullscreenflag == true)
    {
        b.setHeight(rect.height());
        b.setWidth(rect.width());
        ui->video->resize(b);

        ui->open->setVisible(false);
        ui->play->setVisible(false);
        ui->pause->setVisible(false);
        ui->stop->setVisible(false);
        ui->Record->setVisible(false);
        ui->imageprocess->setVisible(false);
    }
    else
    {
        b.setHeight(rect.height()-30);
        b.setWidth(rect.width());
        ui->video->resize(b);

        ui->open->setVisible(true);
        ui->play->setVisible(true);
        ui->pause->setVisible(true);
        ui->stop->setVisible(true);
        ui->Record->setVisible(true);
        ui->imageprocess->setVisible(true);

        ui->open->setGeometry(5,rect.height()-25,60,25);
        ui->play->setGeometry(80, rect.height() - 25,50,25);
        ui->pause->setGeometry(140, rect.height() - 25,50,25);
        ui->stop->setGeometry(200, rect.height() - 25,50,25);
        ui->Record->setGeometry(260, rect.height() - 25,70,25);
        ui->imageprocess->setGeometry(340, rect.height() - 25,90,25);
    }

    this->show();

    // set mediaplayer to player state
    if(pmediapalyer != NULL)
    {
        if(pmediapalyer->get_current_state() == GST_STATE_PAUSED)
        {
           playslot();
        }
    }
}

void playerframe::addmenu()
{

    localfile = new QAction((tr("&localfile"),this));
    localfile->setIconText("file");

    rtsp = new QAction((tr("&rtsp"),this));
    rtsp->setIconText("rtsp");

    axismulticast = new QAction(this);
    axismulticast->setIconText("axismulticast");

    openmenu.addAction(rtsp);
    openmenu.addAction(localfile);
    openmenu.addAction(axismulticast);
    // openmenu.addAction(axismulticast);
    connect(localfile, SIGNAL(triggered()), this, SLOT(openlocalfileslot()));
    connect(rtsp, SIGNAL(triggered()), this, SLOT(openrtspslot()));

}

void playerframe::hideframe()
{
    this->hide();
    if(pmediapalyer != NULL)
    {
        if(pmediapalyer->get_current_state() == GST_STATE_PLAYING)
        {
           pauseslot();
        }
    }
}

void playerframe::openlocalfileslot()
{
    dprintf("openlocalfileslot \n");

    QFileDialog *fd = new QFileDialog(this);
    fd->setWindowTitle("OpenVideo");
    fd->setModal(QFileDialog::ExistingFile);
    fd->setViewMode(QFileDialog::Detail);

    //fd->setFilter("Allfile(*.*);;mp3file(*.mp3);;wmafile(*.wma);;wavefile(*.wav)");     //Filer files
    fd->setNameFilter("*.mp4 *.mts *.ts *.h264 *.avi");

    if (fd->exec() == QDialog::Accepted)
    {
        // QString file = fd->selectedFiles()[0];  // Get detail filename and dir
        //  g_filename[player_id] = fd->selectedFiles()[0];

        dprintf("OpenMediaFile: %s\n",  fd->selectedFiles()[0].toUtf8().constData());

        if(pmediapalyer != NULL)
        {
            delete pmediapalyer;
        }

        pmediapalyer = new localfileplayer;
        pmediapalyer->set_url(fd->selectedFiles()[0]);
        pmediapalyer->createpipeline(ui->video->winId());

        playslot();


        delete fd;

    }
}

void playerframe::openrtspslot()
{
    dprintf("openrtspslot \n");

    prtspdialogframe = new rtspdialogframe();
    prtspdialogframe->setParent(this);
    prtspdialogframe->show();
    //prtspdialogframe->move(this->width()/5, this->height()/3);

    connect(prtspdialogframe,SIGNAL(rtspdialogOKsignal()),this,SLOT(creatertspplayerslot()));


}

void playerframe::creatertspplayerslot()
{
    dprintf("creatertspslot \n");

    if(prtspdialogframe->getrtspaddress() == NULL)
    {
        dprintf("input right rtsp address \n");
        return;
    }
    if(pmediapalyer != NULL)
    {
        delete pmediapalyer;
    }

    pmediapalyer = new rtspplayer(&m_ImageProcessframe);




    pmediapalyer->set_user_name(prtspdialogframe->getuser_name());
    pmediapalyer->set_user_password(prtspdialogframe->getuser_password());
    pmediapalyer->set_url(prtspdialogframe->getrtspaddress());

    pmediapalyer->createpipeline(ui->video->winId());

    playslot();


    delete prtspdialogframe;
}

void playerframe::imageprocessSlot()
{
    dprintf(" playerframe::imageprocessSlot()\n");
     if(pmediapalyer == NULL)
     {
         return;
     }
     if(m_ImageProcessframe.m_ImageProcessType == DO_NOTHING)
     {

        pmediapalyer->imageprocess(false);
     }
     else
     {
         pmediapalyer->imageprocess(true);
     }
}

void playerframe::openaxismulticastslot()
{
     dprintf("openaxismulticastslot");
}

void playerframe::playslot()
{
    pmediapalyer->startplay();
    updateuislot();
}


void playerframe::pauseslot()
{
    pmediapalyer->pause();
    updateuislot();
}


void playerframe::stopslot()
{
    pmediapalyer->stop();
    updateuislot();
}

void playerframe::updateuislot()
{
   // dprintf("playerframe::updateuislot() \n");
    if(pmediapalyer == NULL)
    {
        ui->pause->setEnabled(false);
        ui->play->setEnabled(false);
        ui->stop->setEnabled(false);
        ui->Record->setEnabled(false);
    }
    else
    {
       // dprintf(" get current state = %d \n", pmediapalyer->get_current_state());

        if(pmediapalyer->get_current_state() == GST_STATE_READY)
        {
            ui->pause->setEnabled(false);
            ui->play->setEnabled(true);
            ui->stop->setEnabled(false);
            ui->Record->setEnabled(false);
        }
        else if(pmediapalyer->get_current_state() == GST_STATE_PLAYING)
        {
            ui->play->setEnabled(false);
            ui->pause->setEnabled(true);
            ui->stop->setEnabled(true);
            ui->Record->setEnabled(true);
        }
        else if(pmediapalyer->get_current_state() == GST_STATE_PAUSED)
        {
            ui->play->setEnabled(true);
            ui->pause->setEnabled(false);
            ui->stop->setEnabled(true);
            ui->Record->setEnabled(true);
        }


    }

}

void playerframe::imageprocessconfigslot()
{
    dprintf("playerframe::imageprocessconfigslot()\n");

     m_ImageProcessframe.show();



}
