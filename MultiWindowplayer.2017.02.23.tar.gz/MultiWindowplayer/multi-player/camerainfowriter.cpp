#include "camerainfowriter.h"

camerainfowriter::camerainfowriter()
{
}


bool camerainfowriter::WriteFile(QIODevice *device, CAMERAINFO *p)
{
    if(device==NULL || p==NULL)
    {
           return true;
    }

    xml.setDevice(device);
    xml.setAutoFormatting(true);
    xml.writeStartDocument();
    xml.writeStartElement("CameraInfo");
    xml.writeAttribute("version", "1.0");
    WriteRtspAddress(p);
    WriteUserName(p);
    WriteUserPassword(p);
    xml.writeEndElement();
    xml.writeEndDocument();

}

void camerainfowriter::WriteRtspAddress(CAMERAINFO *p)
{
    QString tagname ="RtspAddress";
    xml.writeTextElement(tagname,p->rtsp_address);
}

void camerainfowriter::WriteUserName(CAMERAINFO *p)
{
    xml.writeTextElement("UserName",p->user_name);
}

void camerainfowriter::WriteUserPassword(CAMERAINFO *p)
{
    xml.writeTextElement("UserPassword",p->user_pw);
}

