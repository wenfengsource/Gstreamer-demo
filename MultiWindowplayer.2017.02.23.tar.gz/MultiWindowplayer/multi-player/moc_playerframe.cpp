/****************************************************************************
** Meta object code from reading C++ file 'playerframe.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.2.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "playerframe.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'playerframe.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.2.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_playerframe_t {
    QByteArrayData data[12];
    char stringdata[169];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    offsetof(qt_meta_stringdata_playerframe_t, stringdata) + ofs \
        - idx * sizeof(QByteArrayData) \
    )
static const qt_meta_stringdata_playerframe_t qt_meta_stringdata_playerframe = {
    {
QT_MOC_LITERAL(0, 0, 11),
QT_MOC_LITERAL(1, 12, 8),
QT_MOC_LITERAL(2, 21, 0),
QT_MOC_LITERAL(3, 22, 8),
QT_MOC_LITERAL(4, 31, 9),
QT_MOC_LITERAL(5, 41, 17),
QT_MOC_LITERAL(6, 59, 21),
QT_MOC_LITERAL(7, 81, 12),
QT_MOC_LITERAL(8, 94, 12),
QT_MOC_LITERAL(9, 107, 20),
QT_MOC_LITERAL(10, 128, 22),
QT_MOC_LITERAL(11, 151, 16)
    },
    "playerframe\0playslot\0\0stopslot\0pauseslot\0"
    "openlocalfileslot\0openaxismulticastslot\0"
    "openrtspslot\0updateuislot\0"
    "creatertspplayerslot\0imageprocessconfigslot\0"
    "imageprocessSlot\0"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_playerframe[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      10,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,   64,    2, 0x08,
       3,    0,   65,    2, 0x08,
       4,    0,   66,    2, 0x08,
       5,    0,   67,    2, 0x08,
       6,    0,   68,    2, 0x08,
       7,    0,   69,    2, 0x08,
       8,    0,   70,    2, 0x08,
       9,    0,   71,    2, 0x08,
      10,    0,   72,    2, 0x08,
      11,    0,   73,    2, 0x08,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void playerframe::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        playerframe *_t = static_cast<playerframe *>(_o);
        switch (_id) {
        case 0: _t->playslot(); break;
        case 1: _t->stopslot(); break;
        case 2: _t->pauseslot(); break;
        case 3: _t->openlocalfileslot(); break;
        case 4: _t->openaxismulticastslot(); break;
        case 5: _t->openrtspslot(); break;
        case 6: _t->updateuislot(); break;
        case 7: _t->creatertspplayerslot(); break;
        case 8: _t->imageprocessconfigslot(); break;
        case 9: _t->imageprocessSlot(); break;
        default: ;
        }
    }
    Q_UNUSED(_a);
}

const QMetaObject playerframe::staticMetaObject = {
    { &QFrame::staticMetaObject, qt_meta_stringdata_playerframe.data,
      qt_meta_data_playerframe,  qt_static_metacall, 0, 0}
};


const QMetaObject *playerframe::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *playerframe::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_playerframe.stringdata))
        return static_cast<void*>(const_cast< playerframe*>(this));
    return QFrame::qt_metacast(_clname);
}

int playerframe::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QFrame::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 10)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 10;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 10)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 10;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
