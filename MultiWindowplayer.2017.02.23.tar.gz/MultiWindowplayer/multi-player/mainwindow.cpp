#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <X11/Xlib.h>
#include <X11/Xutil.h>


#define APP_WIDTH    ((m_srceen_width -50) )
#define APP_HEIGHT   ((m_sreen_height -50) )

#define FULL_APP_WIDTH     (m_srceen_width)
#define FULL_APP_HEIGHT    (m_sreen_height)

int m_srceen_width;
int m_sreen_height;

static int get_screen_resolution (int *pwidth, int *pheight/*Bool current*/);



/*Get currently X window resolution */
static int get_screen_resolution (int *pwidth, int *pheight/*Bool current*/)
{
    Display *dpy;
    int	screen = -1;
    if (!(dpy = XOpenDisplay(NULL)))
    {
        printf(" XOpenDisplay() error !\n");
        return -1;
    }
    screen = DefaultScreen (dpy);
    *pwidth = DisplayWidth (dpy, screen);
    *pheight = DisplayHeight(dpy, screen);
    return 0;

}

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    connect(ui->layout1win, SIGNAL(clicked()), this, SLOT(layout1winslot()));
    connect(ui->layout4win, SIGNAL(clicked()), this, SLOT(layout4winslot()));
    connect(ui->layout9win, SIGNAL(clicked()), this, SLOT(layout9winslot()));
    connect(ui->layout16win, SIGNAL(clicked()), this, SLOT(layout16winslot()));
    connect(ui->FullScreen, SIGNAL(clicked()), this, SLOT(fullscreenslot()));


    get_screen_resolution(&m_srceen_width, &m_sreen_height);

    fullscreenflag = false;
    layout4winslot();

}


MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::showframe()
{
    QRect a;

    a.setRect(0,0, m_srceen_width ,m_sreen_height );

    this->setGeometry(a);
    this->show();
}

void MainWindow::fullscreenslot()
{
    fullscreenflag = true ;

    ui->FullScreen->setVisible(false);
    ui->layout1win->setVisible(false);
    ui->layout4win->setVisible(false);
    ui->layout9win->setVisible(false);
    ui->layout16win->setVisible(false);

    this->showFullScreen();
    layoutmanagement();
}

void MainWindow::mousePressEvent(QMouseEvent *event)
{
    dprintf("mouse press event \n");

    if(fullscreenflag == true)
    {
        fullscreenflag = false;

        ui->FullScreen->setVisible(true);
        ui->layout1win->setVisible(true);
        ui->layout4win->setVisible(true);
        ui->layout9win->setVisible(true);
        ui->layout16win->setVisible(true);

        this->showNormal();
        layoutmanagement();
    }

}

void MainWindow::layoutmanagement()
{
    switch (cur_layout)
    {
        case layout1win:
            layout1winslot();
            break;
        case layout4win:
            layout4winslot();
            break;
        case layout9win:
            layout9winslot();
            break;
        case layout16win:
            layout16winslot();
            break;
        default:
            break;
    }
}

void MainWindow::layout1winslot()
{
    int i;
    QRect a;
    cur_layout = layout1win;

     // show channel 0 frame
    if(fullscreenflag == true)
    {
        a.setRect(0, 0, FULL_APP_WIDTH,FULL_APP_HEIGHT);

        m_playerframe[0].setParent(this);
        m_playerframe[0].showframe(a,fullscreenflag);
    }
    else
    {
        a.setRect(0, 30, APP_WIDTH,APP_HEIGHT);

        m_playerframe[0].setParent(this);
        m_playerframe[0].showframe(a,fullscreenflag);
    }
    // Hide channel 1-15 frame
    for(i=1; i< MAX_CHANNEL; i++)
    {
        m_playerframe[i].hideframe();
    }
}

void MainWindow::layout4winslot()
{
    int i, j;
    QRect a;

    cur_layout = layout4win;

    for(i= 0; i < 2; i++)
    {
        for(j = 0; j< 2; j++)
        {
            if(fullscreenflag == true)
            {
                a.setRect(FULL_APP_WIDTH/2*j, FULL_APP_HEIGHT/2*i, FULL_APP_WIDTH/2, FULL_APP_HEIGHT/2);
                m_playerframe[i*2 + j].setParent(this);
                m_playerframe[i*2 + j].showframe(a,fullscreenflag);
            }
            else
            {
                a.setRect(APP_WIDTH/2*j, APP_HEIGHT/2*i + 30, APP_WIDTH/2, APP_HEIGHT/2);
                m_playerframe[i*2 + j].setParent(this);
                m_playerframe[i*2 + j].showframe(a,fullscreenflag);
            }

        }
    }
    // Hide channel 4-15 frame
    for(i=4; i< MAX_CHANNEL; i++)
    {
        m_playerframe[i].hideframe();
    }
}

void MainWindow::layout9winslot()
{
    int i, j;
    QRect a;
    cur_layout = layout9win;

    for(i= 0; i < 3; i++)
    {
        for(j = 0; j< 3; j++)
        {
            if(fullscreenflag == true)
            {
                a.setRect(FULL_APP_WIDTH/3*j,FULL_APP_HEIGHT/3*i, FULL_APP_WIDTH/3,FULL_APP_HEIGHT/3);
                m_playerframe[i*3 + j].setParent(this);
                m_playerframe[i*3 +j].showframe(a,fullscreenflag);
            }
            else
            {
                a.setRect(APP_WIDTH/3*j,APP_HEIGHT/3*i + 30, APP_WIDTH/3,APP_HEIGHT/3);
                m_playerframe[i*3 + j].setParent(this);
                m_playerframe[i*3 +j].showframe(a,fullscreenflag);
            }

        }

    }
    // Hide channel 9-15 frame
    for(i=9; i< MAX_CHANNEL; i++)
    {
        m_playerframe[i].hideframe();
    }
}

void MainWindow::layout16winslot()
{
    // Line and col both 4*4
    int i, j;
    QRect a;
    cur_layout = layout16win;

    for(i= 0; i < 4; i++)
    {
        for(j = 0; j< 4; j++)
        {
           if(fullscreenflag == true)
           {
               a.setRect(FULL_APP_WIDTH/4*j, FULL_APP_HEIGHT/4*i, FULL_APP_WIDTH/4, FULL_APP_HEIGHT/4);
               m_playerframe[i*4 + j].setParent(this);
               m_playerframe[i*4 +j].showframe(a,fullscreenflag);
           }
           else
           {
                a.setRect(APP_WIDTH/4*j, APP_HEIGHT/4*i + 30, APP_WIDTH/4, APP_HEIGHT/4);
                m_playerframe[i*4 + j].setParent(this);
                m_playerframe[i*4 +j].showframe(a,fullscreenflag);
           }

        }

    }
}
