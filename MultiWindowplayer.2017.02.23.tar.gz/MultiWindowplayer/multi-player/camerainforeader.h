#ifndef CAMERAINFOREADER_H
#define CAMERAINFOREADER_H

#include <QXmlStreamReader>
#include "defines.h"
class Camerainforeader
{
public:
    Camerainforeader();
    bool ReadCameraInfo(QIODevice *device, CAMERAINFO *pCameraInfo);

private:
     QXmlStreamReader xml;
    void SetCameraInfo(CAMERAINFO *p);
    void SetRtspAddress(CAMERAINFO *p);
    void SetUserName(CAMERAINFO *p);
    void SetUserPassword(CAMERAINFO *p);
};

#endif // CAMERAINFOREADER_H
