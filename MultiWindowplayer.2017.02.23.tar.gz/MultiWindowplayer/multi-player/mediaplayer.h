#ifndef MEDIAPLAYER_H
#define MEDIAPLAYER_H

#include <gst/gst.h>
#include <gst/video/videooverlay.h>
#include "defines.h"
#include <QFrame>
//extern void state_changed_cb (GstBus *bus, GstMessage *msg, GstElement *pipeline);
extern void eos_cb (GstBus *bus, GstMessage *msg, GstElement *pipeline);
extern void error_cb (GstBus *bus, GstMessage *msg, GstElement *pipeline);

class mediaplayer
{
public:
    mediaplayer();
    virtual ~mediaplayer();

public:

    virtual void createpipeline(WId id) = 0;
    virtual void startplay() = 0;
    virtual void pause() = 0;
    virtual void stop() = 0;
    virtual void record() = 0;
    virtual void hide() = 0;
    virtual void set_url(QString url) = 0;
    virtual void set_user_name(QString name) = 0;
    virtual void set_user_password(QString password) = 0;
    virtual GstState get_current_state() = 0;
    virtual void imageprocess(bool flag) = 0;

};

#endif // MEDIAPLAYER_H
