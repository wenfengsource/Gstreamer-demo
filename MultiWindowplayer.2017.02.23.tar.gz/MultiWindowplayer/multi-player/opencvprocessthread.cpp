#include "opencvprocessthread.h"

using namespace cv;
// wtb add for fd (2016-03-08 11:23)
using namespace cv::gpu;
// wtb add for fd (2016-03-08 11:23)

opencvprocessthread::opencvprocessthread(QObject *parent) :
    QThread(parent)
{

    m_facedetection = new facedetection();
    m_facedetection_thread = new QThread(this);

    connect(this,SIGNAL(facedetectionbycpusignal(int)),m_facedetection,SLOT(facedetectbycpuSlot(int)));
    connect(this,SIGNAL(facedetectionbyGpusignal(int)),m_facedetection,SLOT(facedetectbyGpuSlot(int)));

   // connect(pImageProcessconfig->ui->GPU,SIGNAL(click()),this,SLOT(facedetectbycpuslot()));
    m_facedetection->moveToThread(m_facedetection_thread);
    m_facedetection_thread->start();

}

opencvprocessthread::~opencvprocessthread()
{
    dprintf("~opencvprocessthread()\n");

    if(m_facedetection != NULL)
    {
        delete m_facedetection;
    }
    if(m_facedetection_thread != NULL)
    {
        while(m_facedetection_thread->isRunning())
        {
            m_facedetection_thread->exit();
            usleep(100); // waitting 0.1 ms
        }
         delete m_facedetection_thread;
    }
}

void opencvprocessthread::setgstcustomdata(CustomData *customdata)
{
      pcustomdata = customdata;
}

void opencvprocessthread::run()
{
    dprintf("opencvprocessthread::run()\n");

    GstSample*    sample;
    GstMapInfo   info;

    GstBuffer*    buffer;
    GstBuffer*    appsrc_buffer;
    GstCaps*      buffer_caps;


    int          width;
    int          height;

    stopflag = false;
     bool first = true;
     m_facedetection->finished  = false;
  //  m_facedetection->finished = true;
    Mat faces_downloaded;

    vector<Rect> facesBuf_cpu;

    while(!stopflag)
    {
        usleep(1000); // 1ms
        if(!pcustomdata->pipeline)
            return  ;

        // bail out if EOS
        if(gst_app_sink_is_eos(GST_APP_SINK(pcustomdata->videosink)))
            return;

        sample = gst_app_sink_pull_sample(GST_APP_SINK(pcustomdata->videosink));

        if(!sample)
            return;

        buffer_caps = gst_sample_get_caps(sample);
        // bail out in no caps
        assert(gst_caps_get_size(buffer_caps) == 1);
        GstStructure* structure = gst_caps_get_structure(buffer_caps, 0);

        // bail out if width or height are 0
        if(!gst_structure_get_int(structure, "width", &width) ||
                !gst_structure_get_int(structure, "height", &height))

        {
            gst_caps_unref(buffer_caps);
            return ;
        }
      //   printf("width = %d height =%d \n" , width, height);

        buffer = gst_sample_get_buffer(sample);

        // Not do image process,
        if(pImageProcessconfig->m_ImageProcessType == DO_NOTHING)
        {
            pre_imageprocesstype = pImageProcessconfig->m_ImageProcessType;

            appsrc_buffer = gst_buffer_copy(buffer);

            gst_app_src_push_buffer(GST_APP_SRC(pcustomdata->sourcefromopencv.appsrc), appsrc_buffer);


            if(sample)
            {
               gst_sample_unref(sample);
            }
            continue;
        }

        // Opencv process
        GstMapInfo map;
        gst_buffer_map (buffer, &map, GST_MAP_READ);

        // I420 format, map.data[0-width*height-1] is Y, mapdata.[width*height- width*1.5] is UV
        //Get I420 Y data is Gray image,
        Mat image(cv::Size(width, height), CV_8UC1, (char*)map.data, cv::Mat::AUTO_STEP);

// ---------------------  wtb opencv faced (2016-03-08 09:07)  ------------------------------------------

      //  m_facedetection->mutex.lock();
        if(height == 600)
        {
           m_facedetection->minScanSize = 40;
        }
        else if((height == 720) || (height == 768))
        {
           m_facedetection->minScanSize = 50;
        }
        else if(height == 800)
        {
           m_facedetection->minScanSize = 55;
        }
        else if(height == 960)
        {
           m_facedetection->minScanSize = 60;
        }
        else if(height == 1024)
        {
           m_facedetection->minScanSize = 70;
        }
        else if(height == 1080)
        {
           m_facedetection->minScanSize = 80;
        }
        else
        {
           m_facedetection->minScanSize = 30;
        }
        //printf("height = %d,minsize = %d,wtb------\n",height,m_facedetection->minScanSize);

        if(first == true)
        {
             first =false;

             m_facedetection->imagecopy(&image);
            if(pImageProcessconfig->useGPU)
            {
                //m_facedetection->getface_rectangle(&faces_downloaded);  //Get detected result
                emit this->facedetectionbyGpusignal(m_facedetection->minScanSize);
            }
            else
            {
               // m_facedetection->getface_rectangle(&facesBuf_cpu);  //Get detected result
                emit this->facedetectionbycpusignal(m_facedetection->minScanSize);  // send execute face detection signal
            }
        }

         m_facedetection->m_mutex.lock();
        if(m_facedetection->finished == true)
        {
            m_facedetection->m_mutex.unlock();

            m_facedetection->imagecopy(&image);

            if(pImageProcessconfig->useGPU)
            {
                detections_num = m_facedetection->detections_num;
                m_facedetection->getface_rectangle(&faces_downloaded);  //Get detected result
                emit this->facedetectionbyGpusignal(m_facedetection->minScanSize);
            }
            else
            {
                m_facedetection->getface_rectangle(&facesBuf_cpu);  //Get detected result
                emit this->facedetectionbycpusignal(m_facedetection->minScanSize);  // send execute face detection signal
            }
           // printf("facesBuf_cpu size = %d\n", (int)m_facedetection->detections_num);

            m_facedetection->finished  = false;

        }
        else
        {
            m_facedetection->m_mutex.unlock();
        }
        /* parameters */
      //  bool findLargestObject = false;
      //  bool filterRects = true;

       // int detections_num;
      //  TickMeter tm;


        if( !image.empty() )
        {
            //wtb add
             IplImage frame = image;
           IplImage* img = &frame;
           float mosaicScale= pImageProcessconfig->GetMosaicScaleFactor();

           if(0.5 > mosaicScale || mosaicScale > 2.5)
           {
               mosaicScale = 1;
           }

           int W=32;
           int H=32;
           float posX,posY,WIDTH,HEIGHT;

            if (!pImageProcessconfig->useGPU && facesBuf_cpu.size() )
            {
                for (unsigned int i = 0; i < facesBuf_cpu.size(); ++i)
                {
                     if(pImageProcessconfig->maskface)
                     {
                         posX = facesBuf_cpu[i].x - (mosaicScale-1)/2*(facesBuf_cpu[i].width);
                         posY = facesBuf_cpu[i].y - (mosaicScale-1)/2*(facesBuf_cpu[i].height);
                         WIDTH = facesBuf_cpu[i].width*mosaicScale;
                         HEIGHT = facesBuf_cpu[i].height*mosaicScale;
                         cvSetImageROI(img,cvRect((int)posX,(int)posY,(int)WIDTH,(int)HEIGHT));

                         for(int mi=W;mi<img->roi->width;mi+=W)
                             for(int mj=H;mj<img->roi->height;mj+=H)
                             {
                                 CvScalar tmp=cvGet2D(img,mj-H/2,mi-W/2);
                                 for(int mx=mi-W;mx<=mi;mx++)
                                     for(int my=mj-H;my<=mj;my++)
                                         cvSet2D(img,my,mx,tmp);
                             }
                         cvResetImageROI(img);
                     }
                     else
                     {
                          rectangle(image, facesBuf_cpu[i], Scalar(255,0,255),3,8,0);
                     }

                }
            }
            if (pImageProcessconfig->useGPU  && detections_num<10)
            {
                 for (int i = 0; i < detections_num; ++i)
                 {

                     if(pImageProcessconfig->maskface)
                     {
                         posX = faces_downloaded.ptr<cv::Rect>()[i].x - (mosaicScale-1)/2*(faces_downloaded.ptr<cv::Rect>()[i].width);
                         posY = faces_downloaded.ptr<cv::Rect>()[i].y - (mosaicScale-1)/2*(faces_downloaded.ptr<cv::Rect>()[i].height);
                         WIDTH = faces_downloaded.ptr<cv::Rect>()[i].width*mosaicScale;
                         HEIGHT = faces_downloaded.ptr<cv::Rect>()[i].height*mosaicScale;
                         cvSetImageROI(img,cvRect((int)posX,(int)posY,(int)WIDTH,(int)HEIGHT));

                         for(int mi=W;mi<img->roi->width;mi+=W)
                             for(int mj=H;mj<img->roi->height;mj+=H)
                             {
                                 CvScalar tmp=cvGet2D(img,mj-H/2,mi-W/2);
                                 for(int mx=mi-W;mx<=mi;mx++)
                                     for(int my=mj-H;my<=mj;my++)
                                         cvSet2D(img,my,mx,tmp);
                             }
                         cvResetImageROI(img);
                     }
                     else
                     {
                         rectangle(image, faces_downloaded.ptr<cv::Rect>()[i], Scalar(255,0,255),3,8,0);
                     }

                 }
            }

        }
        else
        {
            printf(" --(!) No captured frame -- Break!");
            break;
        }


// ---------------------  wtb opencv faced (2016-03-08 09:07)  ------------------------------------------


//        cvtColor(image, edges, CV_RGB2GRAY);
//        GaussianBlur(edges, edges, cv::Size(7,7), 1.5, 1.5);
//        Canny(edges, edges, 0, 30, 3);

        //   imshow("original", image);
        //         waitKey(1);
     //   gst_buffer_unmap (buffer, &map);

        //Push opencv processed data to appsrc
        IplImage image_edge;
        image_edge = image; // wtb change edges to image (2016-03-08 11:25)

        //printf("image_edge.imageSize = %d\n", image_edge.imageSize);
        appsrc_buffer = gst_buffer_new_allocate (NULL, (image_edge.imageSize*1.5), NULL);
        gst_buffer_map(appsrc_buffer, &info, (GstMapFlags)GST_MAP_READ);


        memcpy(info.data, (guint8*)image_edge.imageData, image_edge.imageSize);

            // copy uv data to info.data
        memcpy((info.data + image_edge.imageSize), (map.data + image_edge.imageSize), image_edge.imageSize*0.5);

        gst_buffer_unmap(appsrc_buffer, &info);
        gst_buffer_unmap (buffer, &map);

         gst_app_src_push_buffer(GST_APP_SRC(pcustomdata->sourcefromopencv.appsrc), appsrc_buffer);

         if(sample)
         {
            gst_sample_unref(sample);
         }

    }

    dprintf("end opencvprocessthread \n ");
}


void opencvprocessthread::stop()
{
    stopflag = true;

}

void opencvprocessthread::facedetectbycpuslot(bool a)
{

}
