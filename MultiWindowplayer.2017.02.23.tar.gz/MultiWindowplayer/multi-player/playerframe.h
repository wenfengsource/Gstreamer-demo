#ifndef PLAYERFRAME_H
#define PLAYERFRAME_H
#include "defines.h"
#include "rtspplayer.h"
#include "localfileplayer.h"
#include "mediaplayer.h"
#include "rtspdialogframe.h"
#include "qmenu.h"
#include "imageprocessframe.h"

#include <QFrame>
#include<qtimer.h>

namespace Ui {
class playerframe;
}

class playerframe : public QFrame
{
    Q_OBJECT

public:
    explicit playerframe(QWidget *parent = 0);
    ~playerframe();
    void addmenu();
    void showframe(QRect &rect, bool fullscreenflag);
    void hideframe();

private slots:
    void playslot();
    void stopslot();
    void pauseslot();
    void openlocalfileslot();
    void openaxismulticastslot();
    void openrtspslot();
    void updateuislot();
    void creatertspplayerslot();
    void imageprocessconfigslot();
    void imageprocessSlot();

public:



private:
    Ui::playerframe *ui;
    QMenu openmenu;
     mediaplayer *pmediapalyer;
    rtspdialogframe *prtspdialogframe;
    QTimer *timer;

    QAction *localfile;
    QAction *rtsp;
    QAction *axismulticast;
    ImageProcessframe m_ImageProcessframe;
};

#endif // PLAYERFRAME_H
