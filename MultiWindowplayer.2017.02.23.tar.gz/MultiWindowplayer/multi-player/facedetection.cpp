#include "facedetection.h"

facedetection::facedetection(QObject *parent) :
    QObject(parent)
{

    String face_cascade_name = "haarcascade_frontalface_alt2.xml";
    //String face_cascade_name = "haarcascade_profileface.xml";

    if (!face_cascade_gpu.load(face_cascade_name))
    {
        printf("--(!)Error loading\n");
    return;
    };
    if (!face_cascade_cpu.load(face_cascade_name))
    {
        printf("--(!)Error loading\n");
    return;
    }

}

void facedetection::imagecopy(Mat *img)
{
    img->copyTo(image);
}

void facedetection::facedetectbycpuSlot(int minsize)
{
  // TickMeter tm;

  //  tm.start();

    if( !image.empty())
    {
        Mat gray_cpu;
        image.copyTo(gray_cpu);
       // cvtColor( frame_cpu, gray_cpu, COLOR_RGB2GRAY );
        equalizeHist( gray_cpu, gray_cpu );
        //-- Detect faces
        face_cascade_cpu.detectMultiScale( gray_cpu, facearea_Cpu, 1.2, 2, 0|CV_HAAR_SCALE_IMAGE, Size(minsize, minsize) );
      //  detections_num = (int)facearea_Cpu.size();
     //   printf("detection num=%d\n,",detections_num);
    }

      m_mutex.lock();
    finished = true;
     m_mutex.unlock();

   //tm.stop();
   // double detectionTime = tm.getTimeMilli();
   // double fps = 1000 / detectionTime;

  // printf("detection time = %f\n", detectionTime);
  // printf("detection fps = %f\n", fps);

}

void facedetection::facedetectbyGpuSlot(int minsize)
{
    GpuMat gray_gpu, facesBuf_gpu;
    bool filterRects= true, findLargestObject =false;
    int num;
  //  Mat faces_downloaded;
    gray_gpu.upload(image);

    equalizeHist( gray_gpu, gray_gpu );
    //-- Detect faces
    face_cascade_gpu.findLargestObject = false;

    num = face_cascade_gpu.detectMultiScale(gray_gpu, facesBuf_gpu, 1.2,
                                            (filterRects || findLargestObject) ? 4 : 0,
                                             Size(minsize,minsize));

    facesBuf_gpu.colRange(0, num).download(facearea_Gpu);

    detections_num = num;

    m_mutex.lock();
    finished = true;
    m_mutex.unlock();
}

void facedetection::getface_rectangle(Mat *p)
{
     facearea_Gpu.copyTo(*p);
}

 void facedetection::getface_rectangle(vector<Rect> *p)
{
    *p = facearea_Cpu;
}
