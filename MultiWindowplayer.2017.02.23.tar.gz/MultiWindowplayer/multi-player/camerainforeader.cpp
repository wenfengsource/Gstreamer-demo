#include "camerainforeader.h"

Camerainforeader::Camerainforeader()
{
}

bool Camerainforeader::ReadCameraInfo(QIODevice *device, CAMERAINFO *pCameraInfo)
{
    if((device == NULL) || (pCameraInfo == NULL))
    {
        return false;
    }
    xml.setDevice(device);

    if (xml.readNextStartElement())
    {
            if (xml.name() == "CameraInfo" && xml.attributes().value("version") == "1.0")
            {
                SetCameraInfo(pCameraInfo);
                return true;
            }
            else
            {
                return false;
            }
    }
}


void Camerainforeader::SetCameraInfo(CAMERAINFO *p)
{
     while (xml.readNextStartElement())
     {
         if(xml.name() == "RtspAddress")
         {
             SetRtspAddress(p);
         }
         else if(xml.name() == "UserName")
         {
             SetUserName(p);
         }
         else if(xml.name() == "UserPassword")
         {
             SetUserPassword(p);
         }
     }
}
void Camerainforeader::SetRtspAddress(CAMERAINFO *p)
{
     if(xml.name() == "RtspAddress")
     {
         p->rtsp_address = xml.readElementText();
         dprintf("p->rtsp_address= %s \n",p->rtsp_address.constData())
     }
}

void Camerainforeader::SetUserName(CAMERAINFO *p)
{
    if(xml.name() == "UserName")
    {
        p->user_name = xml.readElementText();
    }
}

void Camerainforeader::SetUserPassword(CAMERAINFO *p)
{
    if(xml.name() == "UserPassword")
    {
        p->user_pw = xml.readElementText();
    }
}


