#ifndef RTSPPLAYER_H
#define RTSPPLAYER_H

#include "mediaplayer.h"
#include "opencvprocessthread.h"
#include "imageprocessframe.h"

class rtspplayer : public mediaplayer
{

public:

    rtspplayer();
    rtspplayer(ImageProcessframe *p);
    ~rtspplayer();

    void createpipeline(WId id);

    void createSourcefromOpencvpipeline();
    void createsinkforOpencvpipeline();

    void startplay();
    void pause();
    void stop();
    void record();
    void hide();

    void set_user_name(QString name);
    void set_user_password(QString password);
    void set_url(QString url);
    GstState get_current_state();
    void imageprocess(bool flag);

private:
    void createpipeline_without_imageprocess();

private:
    QString user_name;
    QString user_pw;
    QString record_flag;
    QString rtsp_url;
    CustomData gstdata;
    WId m_WId;
    opencvprocessthread m_opencvprocessthread;
    ImageProcessframe *pImageProcessconfig;
    bool imageprocess_flag;
};

#endif // RTSPPLAYER_H
