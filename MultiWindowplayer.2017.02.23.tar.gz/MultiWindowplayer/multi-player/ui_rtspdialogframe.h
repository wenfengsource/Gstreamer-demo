/********************************************************************************
** Form generated from reading UI file 'rtspdialogframe.ui'
**
** Created by: Qt User Interface Compiler version 5.2.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_RTSPDIALOGFRAME_H
#define UI_RTSPDIALOGFRAME_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QFrame>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_rtspdialogframe
{
public:
    QLabel *label;
    QLineEdit *rtspaddress;
    QLineEdit *user_name;
    QLineEdit *password;
    QLabel *label_2;
    QLabel *label_3;
    QPushButton *OK;
    QPushButton *CANCLE;
    QPushButton *Load;

    void setupUi(QFrame *rtspdialogframe)
    {
        if (rtspdialogframe->objectName().isEmpty())
            rtspdialogframe->setObjectName(QStringLiteral("rtspdialogframe"));
        rtspdialogframe->resize(522, 141);
        rtspdialogframe->setStyleSheet(QStringLiteral("background-color: rgb(200, 200, 200);"));
        rtspdialogframe->setFrameShape(QFrame::StyledPanel);
        rtspdialogframe->setFrameShadow(QFrame::Raised);
        label = new QLabel(rtspdialogframe);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(20, 20, 67, 17));
        rtspaddress = new QLineEdit(rtspdialogframe);
        rtspaddress->setObjectName(QStringLiteral("rtspaddress"));
        rtspaddress->setGeometry(QRect(100, 20, 211, 27));
        user_name = new QLineEdit(rtspdialogframe);
        user_name->setObjectName(QStringLiteral("user_name"));
        user_name->setGeometry(QRect(100, 60, 61, 27));
        password = new QLineEdit(rtspdialogframe);
        password->setObjectName(QStringLiteral("password"));
        password->setGeometry(QRect(100, 100, 51, 27));
        label_2 = new QLabel(rtspdialogframe);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(20, 60, 41, 20));
        label_3 = new QLabel(rtspdialogframe);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(20, 100, 71, 20));
        OK = new QPushButton(rtspdialogframe);
        OK->setObjectName(QStringLiteral("OK"));
        OK->setGeometry(QRect(390, 100, 99, 27));
        CANCLE = new QPushButton(rtspdialogframe);
        CANCLE->setObjectName(QStringLiteral("CANCLE"));
        CANCLE->setGeometry(QRect(250, 100, 99, 27));
        Load = new QPushButton(rtspdialogframe);
        Load->setObjectName(QStringLiteral("Load"));
        Load->setGeometry(QRect(300, 60, 171, 27));

        retranslateUi(rtspdialogframe);

        QMetaObject::connectSlotsByName(rtspdialogframe);
    } // setupUi

    void retranslateUi(QFrame *rtspdialogframe)
    {
        rtspdialogframe->setWindowTitle(QApplication::translate("rtspdialogframe", "rtsp dialog", 0));
        label->setText(QApplication::translate("rtspdialogframe", "rtsp", 0));
        label_2->setText(QApplication::translate("rtspdialogframe", "user", 0));
        label_3->setText(QApplication::translate("rtspdialogframe", "password", 0));
        OK->setText(QApplication::translate("rtspdialogframe", "OK", 0));
        CANCLE->setText(QApplication::translate("rtspdialogframe", "Cancle", 0));
        Load->setText(QApplication::translate("rtspdialogframe", "LoadCameraInfo", 0));
    } // retranslateUi

};

namespace Ui {
    class rtspdialogframe: public Ui_rtspdialogframe {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_RTSPDIALOGFRAME_H
