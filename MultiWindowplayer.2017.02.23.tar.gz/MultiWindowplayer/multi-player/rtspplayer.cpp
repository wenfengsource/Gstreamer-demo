#include "rtspplayer.h"


/* This function will be called by the pad-added signal */
static void pad_added_handler_for_rtsp (GstElement *src, GstPad *new_pad, GstElement *decode)
{
  GstPad *sink_pad = gst_element_get_static_pad (decode,"sink");
  GstPadLinkReturn ret;
  GstCaps *new_pad_caps = NULL;

  const gchar *new_pad_type = NULL;

  g_print ("Received new pad '%s' from '%s':\n", GST_PAD_NAME (new_pad), GST_ELEMENT_NAME (src));

  /* If our converter is already linked, we have nothing to do here */
  if (gst_pad_is_linked (sink_pad)) {
    g_print ("  We are already linked. Ignoring.\n");
    goto exit;
  }

    if (!strncmp(GST_PAD_NAME (new_pad), "recv_rtp_src_0", 14))
    { // Video pad
         g_print (" video pad\n");
    }
    else
    {
        goto exit;
    }

  /* Attempt the link */
  ret = gst_pad_link (new_pad, sink_pad);
  if (GST_PAD_LINK_FAILED (ret)) {
    g_print ("  Type is '%s' but link failed.\n", new_pad_type);
  } else {
    g_print ("  Link succeeded (type '%s').\n", new_pad_type);
  }

exit:
  /* Unreference the new pad's caps, if we got them */
  if (new_pad_caps != NULL)
    gst_caps_unref (new_pad_caps);

  /* Unreference the sink pad */
  gst_object_unref (sink_pad);
}



/* This function is called when the pipeline changes states. We use it to
 * keep track of the current state. */
static void state_changed_cb (GstBus *bus, GstMessage *msg, CustomData *data)
{
    GstState old_state, new_state, pending_state;
    gst_message_parse_state_changed (msg, &old_state, &new_state, &pending_state);
    if (GST_MESSAGE_SRC (msg) == GST_OBJECT (data->pipeline))
    {
       //  data->current_state = new_state;
        g_print ("State set to %s\n", gst_element_state_get_name (new_state));
        if (old_state == GST_STATE_READY && new_state == GST_STATE_PAUSED)
        {
          /* For extra responsiveness, we refresh the GUI as soon as we reach the PAUSED state */

        }
    }
}



rtspplayer::rtspplayer()
{
    m_opencvprocessthread.setgstcustomdata(&gstdata);

}

rtspplayer::rtspplayer(ImageProcessframe *p)
{
    gstdata.sourcefromopencv.pipeline = NULL;
    gstdata.pipeline = NULL;
    gstdata.bus = NULL;

    m_opencvprocessthread.setgstcustomdata(&gstdata);
    m_opencvprocessthread.pImageProcessconfig = p;

    this->pImageProcessconfig = p;
    imageprocess_flag = pImageProcessconfig->imageprocess_flag;

    dprintf("imageprocess_flag = %d \n",imageprocess_flag);
}

rtspplayer::~rtspplayer()
{
    if(gstdata.bus != NULL)
    {
       gst_object_unref (gstdata.bus);
       gstdata.bus = NULL;
    }

    if(gstdata.pipeline != NULL)
    {
       gst_element_set_state (gstdata.pipeline, GST_STATE_NULL);

       gst_object_unref (gstdata.pipeline);
       gstdata.pipeline = NULL;
    }

    //sourcefromopencv
    if(gstdata.sourcefromopencv.pipeline != NULL)
    {
        gst_element_set_state (gstdata.sourcefromopencv.pipeline, GST_STATE_NULL);

        gst_object_unref (gstdata.sourcefromopencv.pipeline);
        gstdata.sourcefromopencv.pipeline = NULL;
    }

    // exit opencv thread
    while(m_opencvprocessthread.isRunning())
    {
        dprintf("stop opencv thread \n");
        m_opencvprocessthread.stop();
        m_opencvprocessthread.exit();
    }
}



void rtspplayer::createpipeline(WId id)
{
    m_WId = id;

     gst_init(NULL,NULL);
    dprintf("rtspplayer::createpipeline\n");
    if(imageprocess_flag == false)
    {
        createpipeline_without_imageprocess();
    }
    else
    {
         createSourcefromOpencvpipeline();
         createsinkforOpencvpipeline();
    }

}

// This pipeline is used for capture OpenCV processed data
void rtspplayer::createSourcefromOpencvpipeline()
{
    gstdata.sourcefromopencv.pipeline = gst_pipeline_new ("capture_opencv");
    gstdata.sourcefromopencv.appsrc = gst_element_factory_make ("appsrc", "appsrcsource");
    gstdata.sourcefromopencv.videoconvert = gst_element_factory_make ("queue", "videoconvert");
    gstdata.sourcefromopencv.videorendersink = gst_element_factory_make ("xvimagesink", "videorendersink");

    if(!gstdata.sourcefromopencv.pipeline  || !gstdata.sourcefromopencv.appsrc || !gstdata.sourcefromopencv.videoconvert || !gstdata.sourcefromopencv.videorendersink)
    {
        printf(" not all element can created \n");
    }

    gst_bin_add_many (GST_BIN (gstdata.sourcefromopencv.pipeline),gstdata.sourcefromopencv.appsrc, /*gstdata.sourcefromopencv.videoconvert,*/ gstdata.sourcefromopencv.videorendersink,NULL);

    if(!gst_element_link_many (gstdata.sourcefromopencv.appsrc,/* gstdata.sourcefromopencv.videoconvert, */gstdata.sourcefromopencv.videorendersink, NULL))
    {
        printf(" not link all the element \n");
    }

    g_object_set(gstdata.sourcefromopencv.videorendersink, "sync", false, NULL);

    g_object_set(gstdata.sourcefromopencv.appsrc, "format", GST_FORMAT_BYTES, NULL);
    g_object_set(gstdata.sourcefromopencv.appsrc, "emit-signals", false, NULL);
    g_object_set(gstdata.sourcefromopencv.appsrc, "is-live", true, NULL);
  //  g_object_set(gstdata.sourcefromopencv.appsrc, "max-latency", 200, NULL);
    g_object_set(gstdata.sourcefromopencv.appsrc, "block", true, NULL);

//    g_object_set (G_OBJECT (gstdata.sourcefromopencv.appsrc), "caps",
//    gst_caps_new_simple ("video/x-raw",
//                 "format", G_TYPE_STRING, "I420",
//                 "width", G_TYPE_INT, 640,
//                 "height", G_TYPE_INT, 480,
//                  "framerate", GST_TYPE_FRACTION, 50, 1,
//                 NULL), NULL);

  //g_object_set (gstdata.sourcefromopencv.appsrc, "caps", gst_caps_new_simple("video/x-raw","format",G_TYPE_STRING,"GRAY8",NULL), NULL);

   gst_video_overlay_set_window_handle (GST_VIDEO_OVERLAY (gstdata.sourcefromopencv.videorendersink), m_WId);

 //  GstStateChangeReturn ret = gst_element_set_state (gstdata.sourcefromopencv.pipeline,GST_STATE_PLAYING);

//    if (ret == GST_STATE_CHANGE_FAILURE)
//    {
//      g_printerr ("Unable to set the pipeline to the playing state.\n");

//    }
}

// This pipeline is used for post data to OpenCV
void rtspplayer::createsinkforOpencvpipeline()
{
       GstPad *teepad, *sinkpad;
    dprintf("rtspplayer::createpipeline\n");

    gstdata.pipeline = gst_pipeline_new ("rtsp-pipeline");
    gstdata.source = gst_element_factory_make ("rtspsrc", "source");
    gstdata.rtph264depay = gst_element_factory_make ("rtph264depay", "rtph264depay");
    gstdata.h264parse = gst_element_factory_make ("h264parse", "h264parse");


    gstdata.decode = gst_element_factory_make ("omxh264dec", "decode");
    gstdata.videoconvert = gst_element_factory_make ("nvvidconv", "videoconvert");

   // gstdata.tee = gst_element_factory_make ("tee", "tee");

  //  gstdata.queue1 = gst_element_factory_make ("queue", "queue1");
    gstdata.videosink = gst_element_factory_make("appsink","videosink");

    if (!gstdata.pipeline || !gstdata.source || !gstdata.rtph264depay || !gstdata.h264parse || !gstdata.decode || !gstdata.videoconvert || !gstdata.videosink)
    {
       g_printerr ("Not all elements could be created.\n");
    }
    gst_bin_add_many (GST_BIN (gstdata.pipeline), gstdata.source,gstdata.rtph264depay,gstdata.h264parse,gstdata.decode,gstdata.videoconvert, gstdata.videosink,  NULL);

    if (!(gst_element_link_many (gstdata.rtph264depay, gstdata.h264parse, gstdata.decode, gstdata.videoconvert, gstdata.videosink,NULL)))

    {
        dprintf ("Elements could not be linked \n");
    }

//    GstPadTemplate *templ =
//        gst_element_class_get_pad_template (GST_ELEMENT_GET_CLASS (gstdata.tee),
//        "src_%u");
//    teepad = gst_element_request_pad (gstdata.tee, templ, NULL, NULL);
//    sinkpad = gst_element_get_static_pad (gstdata.queue1, "sink");

//    if(!gst_pad_link (teepad, sinkpad))
//    {
//         dprintf ("teepad  sinkpad not be linked \n");
//    }
//    gst_object_unref (sinkpad);

    gstdata.bus = gst_element_get_bus (gstdata.pipeline);

    /* Instruct the bus to emit signals for each received message, and connect to the interesting signals */
    gst_bus_add_signal_watch (gstdata.bus);
    g_signal_connect (G_OBJECT (gstdata.bus), "message::error", (GCallback)error_cb, gstdata.pipeline);
    g_signal_connect (G_OBJECT (gstdata.bus), "message::eos", (GCallback)eos_cb, gstdata.pipeline);
    g_signal_connect (G_OBJECT (gstdata.bus), "message::state-changed", (GCallback)state_changed_cb, &gstdata);
    // g_signal_connect (G_OBJECT (bus), "message::application", (GCallback)application_cb, &data);


    g_signal_connect (gstdata.source, "pad-added", (GCallback)pad_added_handler_for_rtsp, gstdata.rtph264depay);


    dprintf("rtsp_url = %s \n",rtsp_url.toUtf8().constData());

    g_object_set (gstdata.source, "location",rtsp_url.toUtf8().constData(), NULL);  //uri.toUtf8().constData()
    g_object_set (gstdata.source, "user-id", user_name.toUtf8().constData(), NULL);
    g_object_set (gstdata.source, "user-pw", user_pw.toUtf8().constData(), NULL);

    g_object_set (gstdata.source, "latency",200,NULL);

    // appsink property configuration
    g_object_set (gstdata.videosink, "drop", true, NULL);
    g_object_set (gstdata.videosink, "max-buffers", 1, NULL);
    g_object_set (gstdata.videosink, "max-lateness", 0, NULL);
    g_object_set (gstdata.videosink, "sync", false, NULL);
    g_object_set (gstdata.videosink, "render-delay", 0, NULL);
    g_object_set (gstdata.videosink, "emit-signals", false, NULL);

    g_object_set (gstdata.videosink, "caps", gst_caps_new_simple("video/x-raw","format",G_TYPE_STRING,"I420", NULL), NULL);

  //  gst_caps_unref(caps);
}

void rtspplayer::createpipeline_without_imageprocess()
{
    GstPad *teepad, *sinkpad;

    gstdata.pipeline = gst_pipeline_new ("rtsp-pipeline");
    gstdata.source = gst_element_factory_make ("rtspsrc", "source");
    gstdata.rtph264depay = gst_element_factory_make ("rtph264depay", "rtph264depay");
    gstdata.h264parse = gst_element_factory_make ("h264parse", "h264parse");


    gstdata.decode = gst_element_factory_make ("omxh264dec", "decode");
    gstdata.videoconvert = gst_element_factory_make ("nvvidconv", "videoconvert");

    gstdata.videosink = gst_element_factory_make("xvimagesink","videosink");

    if (!gstdata.pipeline || !gstdata.source || !gstdata.rtph264depay || !gstdata.h264parse || !gstdata.decode || !gstdata.videoconvert || !gstdata.videosink)
    {
       g_printerr ("Not all elements could be created.\n");
    }
    gst_bin_add_many (GST_BIN (gstdata.pipeline), gstdata.source,gstdata.rtph264depay,gstdata.h264parse,gstdata.decode,gstdata.videoconvert, gstdata.videosink,  NULL);

    if ((!(gst_element_link_many (gstdata.rtph264depay, gstdata.h264parse, gstdata.decode, gstdata.videoconvert, gstdata.videosink, NULL))))
    {
        dprintf ("Elements could not be linked \n");
    }

//    GstPadTemplate *templ =
//        gst_element_class_get_pad_template (GST_ELEMENT_GET_CLASS (gstdata.tee),
//        "src_%u");
//    teepad = gst_element_request_pad (gstdata.tee, templ, NULL, NULL);
//    sinkpad = gst_element_get_static_pad (gstdata.queue1, "sink");

//    if(!gst_pad_link (teepad, sinkpad))
//    {
//         dprintf ("teepad  sinkpad not be linked \n");
//    }
//    gst_object_unref (sinkpad);

    gstdata.bus = gst_element_get_bus (gstdata.pipeline);

    /* Instruct the bus to emit signals for each received message, and connect to the interesting signals */
    gst_bus_add_signal_watch (gstdata.bus);
    g_signal_connect (G_OBJECT (gstdata.bus), "message::error", (GCallback)error_cb, gstdata.pipeline);
    g_signal_connect (G_OBJECT (gstdata.bus), "message::eos", (GCallback)eos_cb, gstdata.pipeline);
    g_signal_connect (G_OBJECT (gstdata.bus), "message::state-changed", (GCallback)state_changed_cb, &gstdata);
    // g_signal_connect (G_OBJECT (bus), "message::application", (GCallback)application_cb, &data);


    g_signal_connect (gstdata.source, "pad-added", (GCallback)pad_added_handler_for_rtsp, gstdata.rtph264depay);


    dprintf("rtsp_url = %s \n",rtsp_url.toUtf8().constData());

    g_object_set (gstdata.source, "location",rtsp_url.toUtf8().constData(), NULL);  //uri.toUtf8().constData()
    g_object_set (gstdata.source, "user-id", user_name.toUtf8().constData(), NULL);
    g_object_set (gstdata.source, "user-pw", user_pw.toUtf8().constData(), NULL);
    g_object_set (gstdata.source, "latency",200,NULL);
  //  g_object_set (gstdata.videosink, "sync", false, NULL);

    g_object_set (gstdata.decode, "skip-frames", 0, NULL);


    gst_video_overlay_set_window_handle (GST_VIDEO_OVERLAY (gstdata.videosink), m_WId);
}

// Dynamic create pipeline for image process
void rtspplayer::imageprocess(bool flag)
{
    dprintf("imageprocess flag = %u \n", flag);
    imageprocess_flag = flag;
    stop();

    startplay();

}

void rtspplayer::startplay()
{

    GstState st1;
    GstState st2;

    if(gstdata.pipeline == NULL)
    {
        dprintf("gstdata.pipeline == NULL \n");
        createpipeline(m_WId);
    }

    GstStateChangeReturn status = gst_element_set_state(GST_ELEMENT(gstdata.pipeline), GST_STATE_PLAYING);
    if (status == GST_STATE_CHANGE_ASYNC)
    {
       // wait for status update
        status = gst_element_get_state(gstdata.pipeline, &st1, &st2, GST_CLOCK_TIME_NONE);
    }
    if (status == GST_STATE_CHANGE_FAILURE)
    {
       // handleMessage(pipeline);
        gst_object_unref(gstdata.pipeline);
        gstdata.pipeline = NULL;

        dprintf("GST_STATE_CHANGE_FAILURE\n");
        return;
    }

     // Image process enabled, start sourcefromopencv.pipeline
    if(imageprocess_flag == true)
    {
        // Get resolution of video
        GstSample*    sample;
        GstCaps*      buffer_caps;
        int width, height;
        sample = gst_app_sink_pull_sample(GST_APP_SINK(gstdata.videosink));

        if(!sample)
            return;

        buffer_caps = gst_sample_get_caps(sample);
        // bail out in no caps
        // assert(gst_caps_get_size(buffer_caps) == 1);
        GstStructure* structure = gst_caps_get_structure(buffer_caps, 0);

        // bail out if width or height are 0
        if(!gst_structure_get_int(structure, "width", &width) ||
                !gst_structure_get_int(structure, "height", &height))

        {
            gst_caps_unref(buffer_caps);
            return ;
        }

        if(sample)
        {
           gst_sample_unref(sample);
        }
         printf("width = %d height =%d \n" , width, height);

         // According the resolution to config appsrc caps
         g_object_set (G_OBJECT (gstdata.sourcefromopencv.appsrc), "caps",
         gst_caps_new_simple ("video/x-raw",
                      "format", G_TYPE_STRING, "I420",
                      "width", G_TYPE_INT, width,
                      "height", G_TYPE_INT, height,
                       "framerate", GST_TYPE_FRACTION, 50, 1,
                      NULL), NULL);

        GstStateChangeReturn ret = gst_element_set_state (gstdata.sourcefromopencv.pipeline,GST_STATE_PLAYING);

         if(!m_opencvprocessthread.isRunning())
         m_opencvprocessthread.start();
    }

    gstdata.current_state = GST_STATE_PLAYING;
    dprintf("state now playing\n");

}

void rtspplayer::pause()
{
    GstState st1;
    GstState st2;

    dprintf("rtspplayer::pause \n")
   // gst_element_set_state (gstdata.pipeline,GST_STATE_PAUSED);

    GstStateChangeReturn status = gst_element_set_state(GST_ELEMENT(gstdata.pipeline), GST_STATE_PAUSED);
    if (status == GST_STATE_CHANGE_ASYNC)
    {
        // wait for status update

        status = gst_element_get_state(gstdata.pipeline, &st1, &st2, GST_CLOCK_TIME_NONE);
    }
    if (status == GST_STATE_CHANGE_FAILURE)
    {
       // handleMessage(pipeline);
        gst_object_unref(gstdata.pipeline);
        gstdata.pipeline = NULL;

        dprintf("GST_STATE_CHANGE_FAILURE\n");
        return;
    }
    gstdata.current_state = GST_STATE_PAUSED;
}

void rtspplayer::stop()
{
    // exit opencv process thread
    if(m_opencvprocessthread.isRunning())
    {
        dprintf("m_opencvprocessthread.isRunning \n");
        m_opencvprocessthread.stop();
        m_opencvprocessthread.quit();
        usleep(100);
    }
//    // wait opencvprocessthread exit
//    while(!m_opencvprocessthread.isFinished())
//    {
//        usleep(100);
//        dprintf("loop \n");
//    }

    GstState st1;
    GstState st2;

    dprintf("rtspplayer::stop \n");

    if(gstdata.pipeline != NULL)
    {
        GstStateChangeReturn status = gst_element_set_state(GST_ELEMENT(gstdata.pipeline), GST_STATE_NULL);
        if (status == GST_STATE_CHANGE_ASYNC)
        {
            // wait for status update
            status = gst_element_get_state(gstdata.pipeline, &st1, &st2, GST_CLOCK_TIME_NONE);
        }

        if (status == GST_STATE_CHANGE_FAILURE)
        {
            dprintf("GST_STATE_CHANGE_FAILURE\n");
        }

        dprintf("release  gstdata.pipeline \n");

       gst_object_unref (gstdata.pipeline);
       gstdata.pipeline = NULL;
    }


    if(gstdata.bus != NULL)
    {
       dprintf("release gstdata.bus \n");
       gst_object_unref (gstdata.bus);
       gstdata.bus = NULL;
    }


    //sourcefromopencv
    if(gstdata.sourcefromopencv.pipeline != NULL)
    {
        gst_element_set_state (gstdata.sourcefromopencv.pipeline, GST_STATE_NULL);


        GstStateChangeReturn status = gst_element_set_state(GST_ELEMENT(gstdata.sourcefromopencv.pipeline), GST_STATE_NULL);
        if (status == GST_STATE_CHANGE_ASYNC)
        {
            // wait for status update
            status = gst_element_get_state(gstdata.sourcefromopencv.pipeline, &st1, &st2, GST_CLOCK_TIME_NONE);
        }
        if (status == GST_STATE_CHANGE_FAILURE)
        {         
            dprintf("GST_STATE_CHANGE_FAILURE\n");
        }

        dprintf("release gstdata.sourcefromopencv.pipeline \n");

        gst_object_unref (gstdata.sourcefromopencv.pipeline);
        gstdata.sourcefromopencv.pipeline = NULL;
    }

      gstdata.current_state = GST_STATE_READY;

}

void rtspplayer::record()
{

}

void rtspplayer::hide()
{
    pause();
}

void rtspplayer::set_url(QString url)
{
    rtsp_url = url;
}

void rtspplayer::set_user_name(QString name)
{
    user_name = name;
}

void rtspplayer::set_user_password(QString password)
{
    user_pw = password;
}

GstState rtspplayer::get_current_state()
{
    return gstdata.current_state;
}



