#include "mediaplayer.h"



/* This function is called when an error message is posted on the bus */
void error_cb (GstBus *bus, GstMessage *msg, GstElement *pipeline)
{
    GError *err;
    gchar *debug_info;

    /* Print error details on the screen */
    gst_message_parse_error (msg, &err, &debug_info);
    g_printerr ("Error received from element %s: %s\n", GST_OBJECT_NAME (msg->src), err->message);
    g_printerr ("Debugging information: %s\n", debug_info ? debug_info : "none");
    g_clear_error (&err);
    g_free (debug_info);

    /* Set the pipeline to READY (which stops playback) */
    gst_element_set_state (pipeline, GST_STATE_READY);
}


/* This function is called when an End-Of-Stream message is posted on the bus.
 * We just set the pipeline to READY (which stops playback) */
void eos_cb (GstBus *bus, GstMessage *msg, GstElement *pipeline)
{
    g_print ("End-Of-Stream reached.\n");

    gst_element_set_state (pipeline, GST_STATE_READY);

}


mediaplayer::mediaplayer()
{
}

mediaplayer::~mediaplayer()
{

}
