#ifndef DEFINES_H
#define DEFINES_H


#include <glib.h>
#include <gst/gst.h>
#include <gst/video/videooverlay.h>
#include <gst/gstbuffer.h>
#include <gst/video/video.h>
#include <gst/app/gstappsink.h>
#include <gst/app/gstappsrc.h>
#include <assert.h>
#include <unistd.h>
#include <stdio.h>
#include <opencv2/opencv.hpp>
#include <opencv2/gpu/gpu.hpp>
#include <QString>
#include <QDebug>
#include <stdio.h>
#include <unistd.h>

#define dprintf(x...) printf("ui: " x);
//#define dprintf(x...)


#define MAX_CHANNEL     16
#define PANNEL_WIDTH     (1920 -50)
#define PANNEL_HEIGHT    (1080 -50)


enum winlayout
{
    layout1win =0,
    layout4win,
    layout9win,
    layout16win
};

/* Structure to contain all our information, so we can pass it to callbacks */
typedef struct _CustomData {
  GstElement *pipeline;
  GstElement *source;
  GstElement *sdpdemux;
  GstElement *decodebin;

  GstElement *videoconvert;
  GstElement *tee;
  GstElement *queuefordeocode;
  GstElement *queueforrecord;
  GstElement *filesink;
  GstElement *videosink;

  GstBus *bus;
  int loop_player;

} GstCustomData;


typedef struct {
    QString rtsp_address;
    QString user_name;
    QString user_pw;
} CAMERAINFO;

#endif // DEFINES_H


