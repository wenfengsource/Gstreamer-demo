#ifndef FACEDETECTION_H
#define FACEDETECTION_H

#include "defines.h"
#include <QObject>
 #include <QMutex>
using namespace cv;
using namespace cv::gpu;

class facedetection : public QObject
{
    Q_OBJECT
public:
    explicit facedetection(QObject *parent = 0);
    void imagecopy(Mat *img);

    void getface_rectangle(Mat *p);
    void getface_rectangle(vector<Rect> *p);


public:
    Mat image;
    bool finished;
    int detections_num;
    bool Gpudetectionfinished;
     bool cpudetectionfinished;
     int minScanSize;
   QMutex m_mutex;
private:
    CascadeClassifier_GPU face_cascade_gpu;
    CascadeClassifier face_cascade_cpu;
    vector<Rect> facearea_Cpu;
    Mat facearea_Gpu;
signals:
    void finishedfacedetect();

public slots:
    void facedetectbycpuSlot(int minsize);
    void facedetectbyGpuSlot(int minsize);
};

#endif // FACEDETECTION_H
