#ifndef OPENCVPROCESSTHREAD_H
#define OPENCVPROCESSTHREAD_H


#include <QThread>
#include "defines.h"
#include "imageprocessframe.h"
#include "facedetection.h"
//#include<QMutex>
typedef struct {
    GstElement *pipeline;
    GstElement *appsrc;
    GstElement *videoconvert;
    GstElement *videorendersink;

} Captureopencv;

typedef struct  {
  GstElement *pipeline;
  GstElement *source;
  GstElement *rtph264depay;
  GstElement *h264parse;
  GstElement *decode;
  GstElement *tee;
  GstElement *queue1;
  GstElement *queue2;
  GstElement *videosink;

  GstElement *videoconvert;
  GstBus *bus;
  GstState current_state;

  Captureopencv sourcefromopencv;

} CustomData;


class opencvprocessthread : public QThread
{
    Q_OBJECT
public:
    explicit opencvprocessthread(QObject *parent = 0);
    ~opencvprocessthread();
    void setgstcustomdata(CustomData *customdata);
    void run();
    void stop();

public:
    bool stopflag;
    CustomData *pcustomdata;
    ImageProcessframe *pImageProcessconfig;
    facedetection *m_facedetection;
    QThread *m_facedetection_thread;
    int width;
    int height;
   //  bool first;
private:
      int skip_draw;
      int detections_num;
      int pre_imageprocesstype ;
      int pre_Gpu_state;

signals:
    void facedetectionbycpusignal(int);
    void facedetectionbyGpusignal(int);
public slots:
     void facedetectbycpuslot(bool a);
  //  void facedetectbygpuslot(bool);
};

#endif // OPENCVPROCESSTHREAD_H
