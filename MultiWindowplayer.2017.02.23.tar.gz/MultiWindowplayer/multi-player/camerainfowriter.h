#ifndef CAMERAINFOWRITER_H
#define CAMERAINFOWRITER_H

#include <QXmlStreamWriter>
#include "defines.h"
class camerainfowriter
{
public:
    camerainfowriter();
    bool WriteFile(QIODevice *device, CAMERAINFO *p);

private:
    QXmlStreamWriter xml;
    void WriteRtspAddress(CAMERAINFO *p);
    void WriteUserName(CAMERAINFO *p);
    void WriteUserPassword(CAMERAINFO *p);

};

#endif // CAMERAINFOWRITER_H
