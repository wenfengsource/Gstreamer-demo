#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "playerframe.h"
#include "defines.h"
namespace Ui {
class MainWindow;
}



class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

    void showframe();
    void layoutmanagement();
virtual void mousePressEvent ( QMouseEvent * event );

public:
    playerframe m_playerframe[MAX_CHANNEL];
    winlayout cur_layout;
    bool fullscreenflag;

private slots:

     void layout1winslot();
     void layout4winslot();
     void layout9winslot();
     void layout16winslot();

     void fullscreenslot();

private:
    Ui::MainWindow *ui;
};

#endif // MAINWINDOW_H
