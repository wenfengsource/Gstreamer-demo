#ifndef LOCALFILEPLAYER_H
#define LOCALFILEPLAYER_H

#include "defines.h"
#include "mediaplayer.h"

typedef struct  {
  GstElement *pipeline;
  GstElement *source;
  GstElement *rtph264depay;
  GstElement *h264parse;
  GstElement *decode;
  GstElement *tee;
  GstElement *queuefordec;
  GstElement *queueforrecord;
  GstElement *videosink;
  GstElement *videoconvert;
  GstBus *bus;
  GstState current_state;

} fileplayerCustomData;


class localfileplayer : public mediaplayer
{
public:
    localfileplayer();
    ~localfileplayer();

    void createpipeline(WId id);
    void startplay();
    void pause();
    void stop();

    void set_url(QString url);
    void set_user_name(QString name);
    void set_user_password(QString password);
    void record();
    void hide();
    void imageprocess(bool flag);
    GstState get_current_state();

private:
    fileplayerCustomData gstdata;
    QString file_url;
};

#endif // LOCALFILEPLAYER_H
