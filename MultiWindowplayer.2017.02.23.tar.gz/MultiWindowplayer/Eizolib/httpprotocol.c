#include <stdio.h>
#include <time.h>
#include <stdint.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <string.h>

#include <sys/time.h>
#include "httpprotocol.h"
#include "md5.h"

#define SEND_BUF_LEN 256
#define READ_BUF_LEN 20480
#define MSG_LINE_MAX 1024
#define HTTP_HEADER_BLANK_LINE 1

#define UINT32_MAX_PLUS1 		4294967296.0
#define HTTP_PANASONIC_RECVMSG_MAX	(UINT32_MAX_PLUS1/2-1)
#define HTTP_HEADER_FIELD_BUF_LEN	256

#define SETDATA_READ_BUF_LEN 256

static int checkHttpStatas(char *buf, int size){
	/* HTTPステータスチェック */
	int cnt = 0;
	if(buf==NULL){
	    return -99;
	}
	
	//printf("%s\n",buf);
	
	int i=0;
    char statusLine[512] = {0};
    
    int getStatusLine = 0;
	for( cnt = 0; cnt < size; cnt++ ) {
		if( memcmp(&buf[cnt], "HTTP/" , 5 ) == 0 ){
            /*改行までを取得*/
		    for(i=0; i<512; i++){
		        if(buf[cnt+i] == '\r' || buf[cnt+i] == '\n'){
		            getStatusLine = 1;
		            break;
		        }
		        statusLine[i] = buf[cnt+i];		       		        
 		    }
		}
		
		if(getStatusLine == 1){
		    break;
		}
	}
	
	if(getStatusLine == 0){
	    return -98;
	}
	
	char httpVersion[16] = {0};
	int  statusCode = 0;
	char strStatus[16] = {0};

	if(sscanf(statusLine, "%s %d %s", httpVersion, &statusCode, strStatus) == 3){
	    int num = 0;
	    char *tp;
	    tp = strtok(statusLine, " ");
	    while(tp != NULL){
	        if(num==1){
	            statusCode = atoi(tp);
	        }
	        tp = strtok(NULL, " ");
	        if(tp != NULL){
	            num = num + 1;
	        }
	        
	    }

        /*statusの解析*/
	    if(statusCode >= 200 && statusCode < 300){
	        /*成功ケース*/
	        return statusCode;
	    }
	    else{
	        /*失敗ケース*/
	        return statusCode * -1;
	    }	
	
	}
	else{
	    printf("read status line Error\n");
	    return -97;
	}
	
	//予期せぬステータス
    printf("checkHttpStatas Error\n");
	return -1;
}



int LIBCAM_Panasonic_CreateSocket(char *ipAddress, int port)
{
    int fds;                             /* socket FDS */
    struct sockaddr_in serverAddr;
    struct hostent *host;
    

    serverAddr.sin_addr.s_addr = inet_addr(ipAddress);
    if (serverAddr.sin_addr.s_addr == -1) {
        host = gethostbyname(ipAddress);
        if (host == NULL) {
            printf("Error: Failed to gethostbyname.\n");
            return(-1);
        }
    }
    
    serverAddr.sin_port = htons(port);
    serverAddr.sin_family = AF_INET;

    fds = socket(AF_INET, SOCK_STREAM, 0);
    if (fds == -1) {
        printf("Error: Failed to create a socket.\n");
        return(-2);
    }
    
    if (connect(fds, (struct sockaddr *) &serverAddr, sizeof(serverAddr)) == -1) {
//		printf("Error No : %d¥n", errno);
		close( fds );
        return(-3);
    } 

	return(fds);
}

void LIBCAM_Panasonic_CloseSocket(int fds)
{
    while (1){
        char buf[SEND_BUF_LEN];
        int read_size;
        read_size = read(fds, buf, SEND_BUF_LEN);
        if ( read_size > 0 ){
            write(1, buf, read_size);
        } else {
            break;
        }
    }
	//printf("LIBCAM_Panasonic_CloseSocket [%d]close\n",fds);
	close(fds);
}

#define CGITYPE_GET 0
#define CGITYPE_POST 1


int LIBCAM_getAuthorization( T_CAMERA_INFO* p_camera_t, char *method, char *uri, char *body, char *rspbuf, int bufsize, char *authbuf )
{
//response =・スuA1・ス・スMD5・スl + ":" + nonce・スl + ":" + nc・スl + ":" cnonce・スl + ":" + qop・スl + ":" + A2・ス・スMD5・スl・スv・ス・ス MD5 ・スl
// A1 =・スuusername + ":" + realm + ":" + passwd・スv・ス・ス MD5 ・スl
//"qop" ・スw・ス・ス・スq・スフ値・ス・ス "auth" ・ス・ス・スw・ス閧ウ・ス・スネゑソス・ス鼾・ソスA 
// A2 = ・スuMethod + ":" + uri・スl・スv(Method ・ス・ス HTTP ・ス・ス GET ・ス・ス POST ・スフゑソス・ス・ス)
//"qop" ・スフ値・ス・ス "auth-int" ・スネゑソスホ、 
// A2 = ・スuMethod + ":" + uri・スl+ ":" + entity-body・ス・ス MD5 ・スl・スv(entity-body ・スニは、 POST ・ス・ス・スe・スフゑソス・スニ。)

	const char material[] = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
	MD5_CTX state;
	char digest[16] = {0};
	char digesthex[16*2+1] = {0};
	char md5a1[16] = {0};
	char md5a2[16] = {0};
	char md5body[16] = {0};
	char md5a1hex[16*2+1] = {0};
	char md5a2hex[16*2+1] = {0};
	char md5bodyhex[16*2+1] = {0};
	char realm[AUTH_REALM_SIZE+1] = {0};
	char nonce[AUTH_NONCE_SIZE+1] = {0};
	char *bufadr;
	int md5cnt=0;
	int result=0;
	char nc[8+1];
	char cnonce[32+1] = {0};
	char source[256] = {0};
	char encbuf[128] = {0};

	// ・ス・ス・スX・ス|・ス・ス・スX・スL・ス・スi・ス`・スF・スb・スN・ス・ス・スX・スV・スj
	if(rspbuf != NULL){
		// ・スF・スリ包ソス・スo
		bufadr = strstr(rspbuf, "Authenticate: Digest");
		// Digest・スF・ス・ス
		if(bufadr != NULL){
			p_camera_t->authinfo.auth_mode = AUTH_DIGEST;

			// realm・ス・ス・スo
			bufadr = strstr(rspbuf, "realm=\"");
			if((bufadr != NULL) && (result == 0)){
				bufadr += 7;
				for( md5cnt = 0; md5cnt < AUTH_REALM_SIZE; md5cnt++ ) {
					if(bufadr[md5cnt] == '"'){
						result = 0;
						break;
					}
					if(bufadr[md5cnt] == EOF){
						break;
					}
					realm[md5cnt] = bufadr[md5cnt];
				}
				realm[md5cnt] = 0;
				// realm・スX・スV
				if(strcmp(realm,p_camera_t->authinfo.realm) != 0){
					strcpy(p_camera_t->authinfo.realm,realm);
				}
			}
			else{
				//・ス\・ス・スハス・スe・ス[・ズ・スX
				result = -99;
			}

			// nonce・ス・ス・スo
			bufadr = strstr(rspbuf, "nonce=\"");
			if((bufadr != NULL) && (result == 0)){
				bufadr += 7;
				for( md5cnt = 0; md5cnt < AUTH_NONCE_SIZE; md5cnt ++ ) {
					if(bufadr[md5cnt] == '"'){
						result = 0;
						break;
					}
					if(bufadr[md5cnt] == EOF){
						break;
					}
					nonce[md5cnt] = bufadr[md5cnt];
				}
				nonce[md5cnt] = 0;
				// nonce・スX・スV
				if(strcmp(nonce,p_camera_t->authinfo.nonce) != 0){
					strcpy(p_camera_t->authinfo.nonce,nonce);
					p_camera_t->authinfo.nc = 1;
				}
				else{
					p_camera_t->authinfo.nc += 1;
				}
				sprintf(nc, "%08x",p_camera_t->authinfo.nc);
			}
			else{
				//・ス\・ス・スハス・スe・ス[・ズ・スX
				result = -99;
			}

			// qop・スm・スF
			// qop・ス・スauth・スフ場合
			bufadr = strstr(rspbuf, "qop=\"auth\"");
			if( bufadr != NULL ){
				strcpy(p_camera_t->authinfo.qop,"auth");
			}
			else{
				// qop・ス・スauth,auth-int・スフ場合
				bufadr = strstr(rspbuf, "qop=\"auth,auth-int\"");
				if( bufadr != NULL ){
					strcpy(p_camera_t->authinfo.qop,"auth");
				}
				else{
					bufadr = strstr(rspbuf, "qop=\"auth-int\"");
					// qop・ス・スauth-int・スフ場合
					if( bufadr != NULL ){
						strcpy(p_camera_t->authinfo.qop,"auth-int");
					}
				}
			}
			// ・スw・ス・スネゑソス
			if((bufadr == NULL) && (result == 0)){
				//・ス\・ス・スハス・スe・ス[・ズ・スX
				result = -99;
			}

			// algorithm・スm・スF・スiMD5・スプ対会ソス・スj
			bufadr = strstr(rspbuf, "algorithm=\"MD5\"");
			if((bufadr == NULL) && (result == 0)){
				//・ス\・ス・スハス・スe・ス[・ズ・スX
				result = -99;
			}
		}
		// Digest・スF・スリ以外
		else{
			bzero(&p_camera_t->authinfo.nonce, sizeof(p_camera_t->authinfo.nonce));
			bufadr = strstr(rspbuf, "Authenticate: Basic");
			// Basic・スF・ス・ス
			if(bufadr != NULL){
				p_camera_t->authinfo.auth_mode = AUTH_BASIC;
			}
			// ・スF・スリなゑソス
			else{
				p_camera_t->authinfo.auth_mode = AUTH_NON;
			}
		}
	}
	// ・ス・ス・スX・ス|・ス・ス・スX・ス・ス・ス・ス・スi・スF・スリ変更・スネゑソス・スフ為、・スX・スV・スj
	else{
		// Digest・スF・ス・ス
		if(p_camera_t->authinfo.auth_mode == AUTH_DIGEST){
			p_camera_t->authinfo.nc += 1;

			//response =・スuA1・ス・スMD5・スl + ":" + nonce・スl + ":" + nc・スl + ":" cnonce・スl + ":" + qop・スl + ":" + A2・ス・スMD5・スl・スv・ス・ス MD5 ・スl
			// A1 =・スuusername + ":" + realm + ":" + passwd・スv・ス・ス MD5 ・スl
			//"qop" ・スw・ス・ス・スq・スフ値・ス・ス "auth" ・ス・ス・スw・ス閧ウ・ス・スネゑソス・ス鼾・ソスA 
			// A2 = ・スuMethod + ":" + uri・スl・スv(Method ・ス・ス HTTP ・ス・ス GET ・ス・ス POST ・スフゑソス・ス・ス)
			//"qop" ・スフ値・ス・ス "auth-int" ・スネゑソスホ、 
			// A2 = ・スuMethod + ":" + uri・スl+ ":" + entity-body・ス・ス MD5 ・スl・スv(entity-body ・スニは、 POST ・ス・ス・スe・スフゑソス・スニ。)

				const char material[] = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
				MD5_CTX state;
				char digest[16] = {0};
				char digesthex[16*2+1] = {0};
				char md5a1[16] = {0};
				char md5a2[16] = {0};
				char md5body[16] = {0};
				char md5a1hex[16*2+1] = {0};
				char md5a2hex[16*2+1] = {0};
				char md5bodyhex[16*2+1] = {0};
				char realm[AUTH_REALM_SIZE+1] = {0};
				char nonce[AUTH_NONCE_SIZE+1] = {0};
				char *bufadr;
				int md5cnt=0;
				int result=0;
				char nc[8+1];
				char cnonce[32+1] = {0};
				char source[256] = {0};
				char encbuf[128] = {0};

				// ・ス・ス・スX・ス|・ス・ス・スX・スL・ス・スi・ス`・スF・スb・スN・ス・ス・スX・スV・スj
				if(rspbuf != NULL){
					// ・スF・スリ包ソス・スo
					bufadr = strstr(rspbuf, "Authenticate: Digest");
					// Digest・スF・ス・ス
					if(bufadr != NULL){
						p_camera_t->authinfo.auth_mode = AUTH_DIGEST;

						// realm・ス・ス・スo
						bufadr = strstr(rspbuf, "realm=\"");
						if((bufadr != NULL) && (result == 0)){
							bufadr += 7;
							for( md5cnt = 0; md5cnt < AUTH_REALM_SIZE; md5cnt++ ) {
								if(bufadr[md5cnt] == '"'){
									result = 0;
									break;
								}
								if(bufadr[md5cnt] == EOF){
									break;
								}
								realm[md5cnt] = bufadr[md5cnt];
							}
							realm[md5cnt] = 0;
							// realm・スX・スV
							if(strcmp(realm,p_camera_t->authinfo.realm) != 0){
								strcpy(p_camera_t->authinfo.realm,realm);
							}
						}
						else{
							//・ス\・ス・スハス・スe・ス[・ズ・スX
							result = -99;
						}

						// nonce・ス・ス・スo
						bufadr = strstr(rspbuf, "nonce=\"");
						if((bufadr != NULL) && (result == 0)){
							bufadr += 7;
							for( md5cnt = 0; md5cnt < AUTH_NONCE_SIZE; md5cnt ++ ) {
								if(bufadr[md5cnt] == '"'){
									result = 0;
									break;
								}
								if(bufadr[md5cnt] == EOF){
									break;
								}
								nonce[md5cnt] = bufadr[md5cnt];
							}
							nonce[md5cnt] = 0;
							// nonce・スX・スV
							if(strcmp(nonce,p_camera_t->authinfo.nonce) != 0){
								strcpy(p_camera_t->authinfo.nonce,nonce);
								p_camera_t->authinfo.nc = 1;
							}
							else{
								p_camera_t->authinfo.nc += 1;
							}
							sprintf(nc, "%08x",p_camera_t->authinfo.nc);
						}
						else{
							//・ス\・ス・スハス・スe・ス[・ズ・スX
							result = -99;
						}

						// qop・スm・スF
						// qop・ス・スauth・スフ場合
						bufadr = strstr(rspbuf, "qop=\"auth\"");
						if( bufadr != NULL ){
							strcpy(p_camera_t->authinfo.qop,"auth");
						}
						else{
							// qop・ス・スauth,auth-int・スフ場合
							bufadr = strstr(rspbuf, "qop=\"auth,auth-int\"");
							if( bufadr != NULL ){
								strcpy(p_camera_t->authinfo.qop,"auth");
							}
							else{
								bufadr = strstr(rspbuf, "qop=\"auth-int\"");
								// qop・ス・スauth-int・スフ場合
								if( bufadr != NULL ){
									strcpy(p_camera_t->authinfo.qop,"auth-int");
								}
							}
						}
						// ・スw・ス・スネゑソス
						if((bufadr == NULL) && (result == 0)){
							//・ス\・ス・スハス・スe・ス[・ズ・スX
							result = -99;
						}

						// algorithm・スm・スF・スiMD5・スプ対会ソス・スj
						bufadr = strstr(rspbuf, "algorithm=\"MD5\"");
						if((bufadr == NULL) && (result == 0)){
							//・ス\・ス・スハス・スe・ス[・ズ・スX
							result = -99;
						}
					}
					// Digest・スF・スリ以外
					else{
						bzero(&p_camera_t->authinfo.nonce, sizeof(p_camera_t->authinfo.nonce));
						bufadr = strstr(rspbuf, "Authenticate: Basic");
						// Basic・スF・ス・ス
						if(bufadr != NULL){
							p_camera_t->authinfo.auth_mode = AUTH_BASIC;
						}
						// ・スF・スリなゑソス
						else{
							p_camera_t->authinfo.auth_mode = AUTH_NON;
						}
					}
				}
				// ・ス・ス・スX・ス|・ス・ス・スX・ス・ス・ス・ス・スi・スF・スリ変更・スネゑソス・スフ為、・スX・スV・スj
				else{
					// Digest・スF・ス・ス
					if(p_camera_t->authinfo.auth_mode == AUTH_DIGEST){
						p_camera_t->authinfo.nc += 1;
						sprintf(nc, "%08x",p_camera_t->authinfo.nc);
					}
				}

				// Digest・スF・スリゑソス・スツ擾ソス・ス擾・ス・ス・ス・ス
				if((result == 0) && (p_camera_t->authinfo.auth_mode == AUTH_DIGEST)){
					// A1・ス・ス・ス・ス
					sprintf(source, "%s:%s:%s", p_camera_t->username, p_camera_t->authinfo.realm, p_camera_t->password );
					MD5Init(&state);
					MD5Update(&state, (unsigned char *)source, strlen(source));
					MD5Final((unsigned char *)md5a1, &state);
					digestcode_to_hex( (unsigned char *)md5a1, 16, (unsigned char *)md5a1hex );
			//		printf("a1=%s\n",source);
			//		printf("MD5[a1]=%s\n",md5a1hex);
					// A2・ス・ス・ス・ス
					// qop=auth・スフ場合
					if(strcmp(p_camera_t->authinfo.qop,"auth-int") != 0){
						sprintf(source, "%s:%s",method, uri);
					}
					// qop=auth-int・スフ場合
					else{
						// entity-body・ス・ス・ス・ス・スn・スb・スV・ス・ス・ス・ス
						MD5Init(&state);
						MD5Update(&state, (unsigned char *)body, strlen(body));
						MD5Final((unsigned char *)md5body, &state);
						digestcode_to_hex( (unsigned char *)md5body, 16, (unsigned char *)md5bodyhex );
						sprintf(source, "%s:%s:%s",method, uri, md5bodyhex);
					}
					MD5Init(&state);
					MD5Update(&state, (unsigned char *)source, strlen(source));
					MD5Final((unsigned char *)md5a2, &state);
					digestcode_to_hex( (unsigned char *)md5a2, 16, (unsigned char *)md5a2hex );
			//		printf("a2=%s\n",source);
			//		printf("MD5[a2]=%s\n",md5a2hex);

					// cnonce・ス・ス・ス・ス・スi・ス・ス・ス・ス・ス_・ス・ス・ス・ス・ス・ス・スカ撰ソス・スj
					srand((unsigned)time(NULL));
					int i;
					for(i=0;i<32;i++){
						cnonce[i] = material[rand()%(sizeof(material)-1)];
					}
					cnonce[i] = 0;

					// response・ス・ス・ス・ス
					sprintf(source, "%s:%s:%s:%s:%s:%s", md5a1hex, p_camera_t->authinfo.nonce, nc, cnonce, p_camera_t->authinfo.qop, md5a2hex );
					MD5Init(&state);
					MD5Update(&state, (unsigned char *)source, strlen(source));
					MD5Final((unsigned char *)digest, &state);
					digestcode_to_hex( (unsigned char *)digest, 16, (unsigned char *)digesthex );
			//		printf("response=%s\n",source);
			//		printf("MD5[response]=%s\n",digesthex);

					md5cnt =	strlen(p_camera_t->username) + 
								strlen(p_camera_t->authinfo.realm) + 
								strlen(p_camera_t->authinfo.nonce) + 
								strlen(uri) + 
								strlen(cnonce) + 
								strlen(nc) + 
								strlen(digesthex) + 109;
					if( bufsize >= md5cnt ){
						sprintf(authbuf, "Authorization: Digest username=\"%s\",realm=\"%s\",nonce=\"%s\",uri=\"%s\",cnonce=\"%s\",nc=%s,algorithm=MD5,response=\"%s\",qop=\"%s\"", 
						p_camera_t->username, p_camera_t->authinfo.realm, p_camera_t->authinfo.nonce, uri, cnonce, nc, digesthex, p_camera_t->authinfo.qop);
					}
					else{
						result = -1;	// ・スo・スb・スt・ス@・スT・スC・スY・スル擾ソス
					}
				}
				// Basic・スF・ス・ス
				else if(p_camera_t->authinfo.auth_mode == AUTH_BASIC){
					/* Basic・スF・スリ対会ソス */
					/* "username:password" ・ス・スBase64・スナエ・ス・ス・スR・ス[・スh・ス・ス・ス・ス */
					sprintf(source, "%s:%s", p_camera_t->username, p_camera_t->password );
					base64Encode((unsigned char *)source, (unsigned char *)encbuf, strlen(source));
					md5cnt = strlen(encbuf) + 21;
					if( bufsize >= md5cnt ){
						sprintf(authbuf, "Authorization: Basic %s", encbuf);
						result = 0;
					}
					else{
						result = -1;	// ・スo・スb・スt・ス@・スT・スC・スY・スル擾ソス
					}
					// ・ス・ス・スX・ス|・ス・ス・スX・スR・ス[・スh・ス・ス・スフチ・スF・スb・スN・スヘ厄ソス・ス・ス・スラ、・ス・ス・ス・スI・ス・ス
				}
				// ・スF・スリなゑソス
				else if(p_camera_t->authinfo.auth_mode == AUTH_NON){
					authbuf[0] = 0;
					result = 0;
				}
				// ・スル常発・ス・ス
				else{
				}

			//	printf("\n######strlen(authbuf)[%d]\n%s\n", strlen(authbuf), authbuf);
			//	printf("\n######strlen(authbuf)[%d] nonce=[%s] nc=[%d]\n", strlen(authbuf),p_camera_t->authinfo.nonce,p_camera_t->authinfo.nc);
			//	printf("\n######md5cnt[%d] \n", md5cnt);
				return result;
}


static int SendCGICommand(T_CAMERA_INFO* p_camera_t, char *url, int commandType, char *command, int size, int *ret_rpsindex, char *ret_rspbuf)
{
    struct sockaddr_in local_addr;
    struct sockaddr_in dst_addr;
    socklen_t len = sizeof(local_addr);

    char encbuf[512] = {0};
    char method[8] = {0};
    char uri[32] = {0};
    char bsendbuf[512] = {0};
    fd_set readfds, writefds;
    struct timeval tv;
    struct timespec timeout;
    long lTime;
    int iBodyLen = 0;
    int iHttpHeaderReadFinished = FALSE;
    int iTotalReadBodySize;


    /*ソケットを作成*/
    int fds = LIBCAM_Panasonic_CreateSocket(p_camera_t->ipaddr, p_camera_t->uCamCntrInfo.strCgiInfo.http_port);

    if (fds < 0 ){
        printf("LIBCAM_Panasonic Socket Create Err\n");
        return fds;
    }
    /* HTTPポート番号取得 */
    getsockname( fds, (struct sockaddr *)(&local_addr), &len );

    /* サーバー側のIPアドレス、ポート番号設定 */
    memset(&dst_addr, 0x00, sizeof(dst_addr));
    dst_addr.sin_family = AF_INET;
    dst_addr.sin_port = htons(p_camera_t->uCamCntrInfo.strCgiInfo.http_port);
    inet_aton( p_camera_t->ipaddr, &dst_addr.sin_addr );
        
    /* uri抽出 */
    int i, urlcnt;
    for(i=0 ; i < strlen(url) ; i++){
        if(url[i] == '/'){
            break;
        }
    }
    for(urlcnt=0 ; ; urlcnt++){
        if((url[i+urlcnt] != '?') && (url[i+urlcnt] != 0)){
            uri[urlcnt] = url[i+urlcnt];
            uri[urlcnt+1] = 0;
        }
        else{
            break;
        }
    }
    uri[urlcnt] = 0;
    if(commandType==CGITYPE_GET){
        strcpy(method,"GET");
    }
    else{
        strcpy(method,"POST");
        strcat(uri,"?Language=1");
    }
	
    // 認証取得／設定（Basic/Digest）
    p_camera_t->authinfo.auth_mode = AUTH_NON;
    int checkHttp = LIBCAM_getAuthorization( p_camera_t, method, uri, command, NULL, sizeof(encbuf), encbuf );
    
    /* エラー発生	*/
    if( checkHttp < 0 ){
        return checkHttp;
    }

    if(commandType==CGITYPE_GET){
        if(encbuf[0] == '\0'){
            sprintf(bsendbuf, "%s%s HTTP/1.1\r\nHost: %s:%d\r\nCache-Control: no-cache\r\n\r\n", 
                   url, command, inet_ntoa(dst_addr.sin_addr), ntohs(dst_addr.sin_port));
        }
        else{
            sprintf(bsendbuf, "%s%s HTTP/1.1\r\nHost: %s:%d\r\nCache-Control: no-cache\r\n%s\r\n\r\n", 
                   url, command, inet_ntoa(dst_addr.sin_addr), ntohs(dst_addr.sin_port), encbuf);
       }
    }
    else if(commandType==CGITYPE_POST){
        if(encbuf[0] == '\0'){
            sprintf(bsendbuf, "%sLanguage=1 HTTP/1.1\r\nHost: %s:%d\r\nCache-Control: no-cache\r\nContent-Length: %d\r\n\r\n%s", 
                    url, inet_ntoa(dst_addr.sin_addr), ntohs(dst_addr.sin_port), size, command);                     
        }
        else{
            sprintf(bsendbuf, "%sLanguage=1 HTTP/1.1\r\nHost: %s:%d\r\nCache-Control: no-cache\r\n%s\r\nContent-Length: %d\r\n\r\n%s", 
                    url, inet_ntoa(dst_addr.sin_addr), ntohs(dst_addr.sin_port), encbuf, size, command);         
        }
    }
    else{
        close(fds);
        return -99;
    }
		
    /* for debug */
//	printf("%s\n", bsendbuf);
	
    // fd_set init
    FD_ZERO(&readfds);
    FD_ZERO(&writefds);
    /* selectで待つ読み込みソケットとしてfdsを登録します */
    FD_SET(fds, &readfds);
    FD_SET(fds, &writefds);

    tv.tv_sec = 15;
    tv.tv_usec = 0;

    clock_gettime(CLOCK_REALTIME, &timeout);
    lTime = timeout.tv_sec;

    if( select(fds+1, NULL, &writefds, NULL, &tv) <= 0 ){
        printf("write ERROR!!! select()\n");
        clock_gettime(CLOCK_REALTIME, &timeout);
        printf("time:: %d sec\n", (int)(timeout.tv_sec - lTime));
        close(fds);
        return -99;
    }

    /* fdsに書き込み可能データがない場合 */
    if (!FD_ISSET(fds, &writefds)){
        printf("ERROR!!! empty write data\n");
        close(fds);
        return -99;
    }

    /*CGIコマンド送信*/
    write(fds, bsendbuf, strlen(bsendbuf));
	
    /*カメラからの応答を取得*/
    int read_size = 0;
    int rspindex = 0;
    char rdbuf[READ_BUF_LEN] = {0};

    //char rspbuf[READ_BUF_LEN] = {0};

    tv.tv_sec = 15;
    tv.tv_usec = 0;

    clock_gettime(CLOCK_REALTIME, &timeout);
    lTime = timeout.tv_sec;

    iHttpHeaderReadFinished = FALSE;
    iTotalReadBodySize = 0;

    while (1){
    	/* 読み込み用fd_setの初期化 */
    	/* fdsに設定されたソケットが読み込み可能になるまで待ちます */
    	if( select(fds+1, &readfds, NULL, NULL, &tv) <= 0 ){
            printf("read ERROR!!! select()\n");
            clock_gettime(CLOCK_REALTIME, &timeout);
            printf("time:: %d sec\n", (int)(timeout.tv_sec - lTime));
            close(fds);
            return -99;
    	}

       /* HTTPヘッダの解析 */
        if(iHttpHeaderReadFinished != TRUE){
            iBodyLen = http_recvHead(fds, &rspindex, ret_rspbuf);
            iHttpHeaderReadFinished = TRUE;
        }
        
     	/* fdsに読み込み可能データがない場合 */
    	if (!FD_ISSET(fds, &readfds)){
            printf("ERROR!!! empty read data\n");
            close(fds);
            return -99;
    	}
        read_size = read(fds, rdbuf, READ_BUF_LEN);
        
        if ( read_size > 0 ){
            if(rspindex+read_size < READ_BUF_LEN){
            	//memcpy(&rspbuf[rspindex],rdbuf,read_size);
            	memcpy(&ret_rspbuf[rspindex],rdbuf,read_size);
            	rspindex += read_size;
                iTotalReadBodySize += read_size;
                if(iBodyLen >= 0){ // HTTPヘッダにContent-lengthがない場合、iBodyLenは負の値をとる
                    if( iTotalReadBodySize >= iBodyLen ){
                        break;
                    }
                }
            }
            else{
            	break;
            }
        } else {
            break;
        }
    }


    /*ソケットをクローズ*/
    close(fds);
    
    /* HTTPステータスチェック */
    //int checkHttp = checkHttpStatas(rspbuf, rspindex); 
    checkHttp = checkHttpStatas(ret_rspbuf, rspindex); 
	
    /* 認証失敗（承認コード更新しリトライ）	*/
    if( checkHttp == -401 ){
        /*ソケットを作成*/
        fds = LIBCAM_Panasonic_CreateSocket(p_camera_t->ipaddr, p_camera_t->uCamCntrInfo.strCgiInfo.http_port);
        if (fds < 0 ){
            printf("LIBCAM_Panasonic Socket Create Err\n");
            return -1;
        }
        /* HTTPポート番号取得 */
        getsockname( fds, (struct sockaddr *)(&local_addr), &len );

        // 認証取得／設定（Basic/Digest）
        checkHttp = LIBCAM_getAuthorization( p_camera_t, method, uri, command, ret_rspbuf, sizeof(encbuf), encbuf );
        /* エラー発生	*/
        if( checkHttp < 0 ){
            return checkHttp;
        }

        if(commandType==CGITYPE_GET){
            if(encbuf[0] == '\0'){
                 sprintf(bsendbuf, "%s%s HTTP/1.1\r\nHost: %s:%d\r\nCache-Control: no-cache\r\n\r\n", 
                       url, command, inet_ntoa(dst_addr.sin_addr), ntohs(dst_addr.sin_port));
             }
             else{
                 sprintf(bsendbuf, "%s%s HTTP/1.1\r\nHost: %s:%d\r\nCache-Control: no-cache\r\n%s\r\n\r\n", 
                       url, command, inet_ntoa(dst_addr.sin_addr), ntohs(dst_addr.sin_port), encbuf);
            }       
        }
        else if(commandType==CGITYPE_POST){
            if(encbuf[0] == '\0'){
               sprintf(bsendbuf, "%sLanguage=1 HTTP/1.1\r\nHost: %s:%d\r\nCache-Control: no-cache\r\nContent-Length: %d\r\n\r\n%s", 
                        url, inet_ntoa(dst_addr.sin_addr), ntohs(dst_addr.sin_port), size, command);                     
            }
            else{
               sprintf(bsendbuf, "%sLanguage=1 HTTP/1.1\r\nHost: %s:%d\r\nCache-Control: no-cache\r\n%s\r\nContent-Length: %d\r\n\r\n%s", 
                        url, inet_ntoa(dst_addr.sin_addr), ntohs(dst_addr.sin_port), encbuf, size, command);         
            }
        }
        else{
            close(fds);
            return -99;
        }
		
        /* for debug */
        //printf("%s\n", bsendbuf);

        // fd_set init.
        FD_ZERO(&readfds);
        FD_ZERO(&writefds);
        /* selectで待つ読み込みソケットとしてfdsを登録します */
        FD_SET(fds, &readfds);
        FD_SET(fds, &writefds);

        tv.tv_sec = 15;
        tv.tv_usec = 0;

        clock_gettime(CLOCK_REALTIME, &timeout);
        lTime = timeout.tv_sec;

        if( select(fds+1, NULL, &writefds, NULL, &tv) <= 0 ){
            printf("retry to write ERROR!!! select()\n");
            clock_gettime(CLOCK_REALTIME, &timeout);
            printf("time:: %d sec\n", (int)(timeout.tv_sec - lTime));
            close(fds);
            return -99;
        }

        /* fdsに書き込み可能データがない場合 */
        if (!FD_ISSET(fds, &writefds)){
            printf("ERROR!!! empty write data\n");
            close(fds);
            return -99;
        }
        /*CGIコマンド送信*/
        write(fds, bsendbuf, strlen(bsendbuf));

        /*カメラからの応答を取得*/
        read_size = 0;
        rspindex = 0;
        char rdbuf[READ_BUF_LEN] = {0};
        //char rspbuf[READ_BUF_LEN] = {0};

        clock_gettime(CLOCK_REALTIME, &timeout);
        lTime = timeout.tv_sec;

        tv.tv_sec = 15;
        tv.tv_usec = 0;

        iHttpHeaderReadFinished = FALSE;
        iTotalReadBodySize = 0;
        
        while (1){
            /* 読み込み用fd_setの初期化 */
            /* fdsに設定されたソケットが読み込み可能になるまで待ちます */
            if( select(fds+1, &readfds, NULL, NULL, &tv) <= 0 ){
                printf("retry to read ERROR!!! select()\n");
                clock_gettime(CLOCK_REALTIME, &timeout);
                printf("time:: %d sec\n", (int)(timeout.tv_sec - lTime));
                close(fds);
                return -99;
            }

            /* HTTPヘッダの解析 */
            if(iHttpHeaderReadFinished != TRUE){
                iBodyLen = http_recvHead(fds, &rspindex, ret_rspbuf);
                iHttpHeaderReadFinished = TRUE;
            }
        
           /* fdsに読み込み可能データがない場合 */
            if (!FD_ISSET(fds, &readfds)){
                printf("ERROR!!! empty read data\n");
                close(fds);
                return -99;
            }
            read_size = read(fds, rdbuf, READ_BUF_LEN);
			
            if ( read_size > 0 ){
                if(rspindex+read_size < READ_BUF_LEN){
                    //memcpy(&rspbuf[rspindex],rdbuf,read_size);
                    memcpy(&ret_rspbuf[rspindex],rdbuf,read_size);
                    rspindex += read_size;
                    iTotalReadBodySize += read_size;
                    if(iBodyLen >= 0){ // HTTPヘッダにContent-lengthがない場合、iBodyLenは負の値をとる
                        if( iTotalReadBodySize >= iBodyLen ){
                            break;
                        }
                    }
                }
                else{
                     break;
                }
            } else {
                break;
            }
        }

        
        /*ソケットをクローズ*/
        close(fds);

        /* HTTPステータスチェック */
        checkHttp = checkHttpStatas(ret_rspbuf, rspindex); 
    }

    /*内容を返す*/
    *ret_rpsindex = rspindex;

    return checkHttp;
}



