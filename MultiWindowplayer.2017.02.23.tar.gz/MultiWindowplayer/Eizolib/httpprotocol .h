#ifndef _LIBCAM_PANASONIC_CGICOMMAND_H_
#define _LIBCAM_PANASONIC_CGICOMMAND_H_

#ifdef __cplusplus
extern "C"{
#endif


// 認証情報
#define	AUTH_NONCE_SIZE	32
#define	AUTH_REALM_SIZE	32
#define	AUTH_QOP_SIZE	8
#define IP_ADDRESS_LEN                    16
typedef enum {
	AUTH_NON = 0,			// 認証なし
	AUTH_BASIC,				// Basic認証
	AUTH_DIGEST				// Digest認証
} AUTH_TYPE_e;
typedef struct {
	int	auth_mode;					// 認証モード（Basic/Digest）
	int nc;							// nonce回数
	char nonce[AUTH_NONCE_SIZE+1];	// nonce
	char realm[AUTH_REALM_SIZE+1];	// realm
	char qop[AUTH_QOP_SIZE+1];		// qop
} T_AUTH_INFO;



typedef struct {
	int		id;				     // カメラID(0-15)
	char	ipaddr[IP_ADDRESS_LEN]; // カメラIPアドレス
	char	username[32+1];	     // ユーザー名(1-32)
	char	password[32+1];	     // パスワード(4-32)
	int    TransportType;        // Panasonic_CGI:0, RTSP(ONVIF):1
    unsigned char  ucStreamType; //配信種別(0:unicast, 1:multicast)
	unsigned char ConnectivityAlert; 		// 0:Disable , 1:Enable
	//T_CAMERA_CNTR_INFO uCamCntrInfo; //カメラ制御情報（CGI or RTSP)
	//T_RTP_INFO		rtpinfo;
//	T_H264_PARAM	h264param[2];	// stream1,2
//	T_OTHER_INFO	otherinfo;
	T_AUTH_INFO		authinfo;		// 認証情報

	int		connect;		// 接続フラグ(動画配信開始要求時、connect=1がセットされているカメラが配信対象となる)

    void	(*callback)(int id, int code, int localPort);	// 配信終了コールバック関数
                                                            // id   カメラID
                                                            // code 7:正常終了(動的パラメータ設定時含む)  7以外:connect error
                                                            // localPort   RTPローカルポート番号

} T_CAMERA_INFO;



#ifdef __cplusplus
}
#endif
#endif	//  _LIBCAM_PANASONIC_CGICOMMAND_H_


